"""Diagnostic script to verify Phi-3 mini GPU inference.

Run this script from the repository root to ensure that the Phi-3 mini model
loads correctly on the GPU and can generate a short completion.
"""

from transformers import AutoTokenizer, AutoModelForCausalLM
import torch


def main():
    model_path = "X:/models/phi3-mini"
    tokenizer = AutoTokenizer.from_pretrained(model_path, trust_remote_code=True)
    model = AutoModelForCausalLM.from_pretrained(
        model_path,
        device_map="auto",
        torch_dtype=torch.float16,
        trust_remote_code=True
    )

    device = "cuda" if torch.cuda.is_available() else "cpu"
    print(f"Model loaded on {device}")

    inputs = tokenizer("Test prompt: summarize the purpose of data quality rules.", return_tensors="pt").to(device)
    with torch.no_grad():
        output = model.generate(**inputs, max_new_tokens=50)
    print("Generated text:")
    print(tokenizer.decode(output[0], skip_special_tokens=True))


if __name__ == "__main__":
    main()