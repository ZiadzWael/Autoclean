"""AutoClean PH1 package root.

This file allows the AUTOCLEAN_PH1 directory to be imported as a Python
package. It intentionally exports no symbols.
"""