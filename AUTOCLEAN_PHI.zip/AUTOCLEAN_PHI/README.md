# AutoClean – Production‑Ready Data Cleaning Assistant

AutoClean is a fully local, end‑to‑end data cleaning system that combines LLM‑driven reasoning with rule‑based validation.  It can detect, explain and fix data quality issues in tabular datasets via a rich web interface.  The **production‑ready** version goes beyond basic heuristics: it can discover approximate and conditional functional dependencies, correlated missing value patterns, and domain‑specific formats (email, phone, dates, credit cards).  The frontend has been refactored into a multi‑step wizard with interactive rule management, charts summarising the cleaning operations, and export options for CSV and Excel.

## Features

* **Heuristic and domain‑aware rule extraction** – infer not‑null, unique and numeric range constraints from the data profile.  Additional heuristics derive:
  - **Categorical constraints** for low‑cardinality columns
  - **Generic regex patterns** describing allowed characters
  - **Domain‑specific regex patterns** for email addresses, phone numbers, ISO/UK date formats and credit card numbers
  - **Exact and approximate functional dependencies** (``A → B``) where occasional violations are tolerated
  - **Conditional functional dependencies** (``A → B | C``) that hold only within subsets defined by a condition column
  - **Statistical outlier thresholds** (mean ± *z*·σ)
  - **Case standardisation suggestions** to unify uppercase/lowercase strings
  - **Inclusion dependencies** where one column’s values form a subset of another’s
  - **Correlated missing value patterns** indicating that when column ``A`` is missing, column ``B`` should also be missing

* **Interactive rule management** – extracted rules are stored with unique IDs.  The UI allows you to enable/disable or delete individual rules and apply only a selected subset during cleaning.  You can update a rule via a PUT request.

* **Validation and audit** – validate datasets against any stored rule set.  Violations are counted per rule.  After cleaning, the system returns the cleaned dataset plus a detailed log of every cell change, grouped by rule ID.

* **Rich visualisation** – the multi‑step interface displays extracted rules, validation results, and cleaning modifications.  A bar chart summarises how many changes were triggered by each rule type.

* **Export options** – download cleaned data in CSV or Excel format.  Audit logs can be exported via the API.

* **Multi‑step workflow** – the frontend guides you through uploading a dataset, extracting and managing rules, validating the data, and applying selected rules.  Progress indicators help users understand where they are in the process.

* **Extensible architecture** – modular services for profiling, rule extraction, application and feedback.  The rule engine and LLM client can be swapped or extended with domain‑specific logic.  The project lays the foundation for caching results, streaming large datasets and adding authentication or multi‑user support.

## Requirements

- **Python** ≥ 3.11  
- **Node.js** ≥ 18 (for the React frontend)  
- **GPU** with at least 4 GB VRAM for Phi‑3‑mini (or change to a smaller model)  
- Local file system access for storing rules and vector indices

## Installation

1. **Clone or extract** this repository.  The tree should look like:

    ```
    AUTOCLEAN_PH1/
    ├── backend/             # FastAPI application
    │   ├── app/
    │   │   ├── api/         # REST endpoints
    │   │   ├── services/    # Business logic: LLM clients, RAG, rule extraction, validation
    │   │   ├── db/          # ORM models (for future extension)
    │   │   ├── config.py    # Configuration constants
    │   │   └── main.py      # FastAPI entrypoint
    │   └── scripts/
    ├── data/                # Local storage for uploaded files, rules and vector DB
    ├── frontend/            # React app powered by Vite
    │   ├── src/
    │   │   ├── App.jsx      # Main UI component
    │   │   └── main.jsx     # React entrypoint
    │   ├── index.html       # HTML template
    │   ├── package.json     # Frontend dependencies
    │   └── vite.config.js   # Vite dev‑server config
    ├── ml/                  # ML scripts (e.g., Phi‑3 GPU test)
    ├── README.md            # This file
    └── ...
    ```

2. **Backend setup** (Python):
   ```bash
   # Create and activate a virtual environment (optional but recommended)
   python -m venv venv
   source venv/bin/activate  # On Windows: venv\Scripts\activate

   # Install Python dependencies
   pip install -r backend/app/requirements.txt

   # Start the FastAPI server on port 8001
   uvicorn backend.app.main:app --reload --port 8001
   ```

3. **Frontend setup** (Node.js):
   ```bash
   cd frontend
   npm install        # install React, Vite and related packages
   npm run dev        # launch the development server on port 3000
   ```

   The UI will be available at `http://localhost:3000`.  It proxies API requests to `http://localhost:8001`.