import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

export default defineConfig({
  plugins: [react()],
  server: {
    port: 3000,
    proxy: {
      '/api': 'http://127.0.0.1:8001',
      '/ingest': 'http://127.0.0.1:8001',
      '/extract': 'http://127.0.0.1:8001',
      '/validate': 'http://127.0.0.1:8001',
      '/apply': 'http://127.0.0.1:8001',
      '/rules': 'http://127.0.0.1:8001'
    }
  }
})