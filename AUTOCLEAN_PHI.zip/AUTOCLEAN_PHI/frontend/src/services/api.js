// API Client for AUTOCLEAN Frontend
// Handles all HTTP requests to the backend

const API_BASE_URL = import.meta.env.VITE_API_URL || 'http://localhost:8001';

class APIClient {
  constructor(baseURL = API_BASE_URL) {
    this.baseURL = baseURL;
  }

  async request(endpoint, options = {}) {
    const url = `${this.baseURL}${endpoint}`;
    const defaultHeaders = {
      'Content-Type': 'application/json',
    };

    const config = {
      headers: { ...defaultHeaders, ...options.headers },
      ...options,
    };

    try {
      const response = await fetch(url, config);
      
      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.detail || error.message || `HTTP ${response.status}`);
      }

      return await response.json();
    } catch (error) {
      console.error('API Error:', error);
      throw error;
    }
  }

  // Dataset operations - Ingest
  async uploadFile(file) {
    const formData = new FormData();
    formData.append('file', file);
    
    return this.request('/ingest/', {
      method: 'POST',
      headers: {}, // Remove Content-Type to let browser set it with boundary
      body: formData,
    });
  }

  async uploadDataset(file) {
    return this.uploadFile(file);
  }

  async getDatasetPreview(datasetId) {
    return this.request(`/dataset/${datasetId}/preview`);
  }

  async getDatasetInfo(datasetId) {
    return this.request(`/dataset/${datasetId}/info`);
  }

  // Rule extraction
  async extractRules(file) {
    const formData = new FormData();
    formData.append('file', file);
    
    return this.request('/extract/', {
      method: 'POST',
      headers: {}, // Remove Content-Type to let browser set it with boundary
      body: formData,
    });
  }

  async getRules(datasetId) {
    return this.request(`/rules?dataset_id=${datasetId}`);
  }

  async updateRule(ruleId, ruleData) {
    return this.request(`/rules/${ruleId}`, {
      method: 'PUT',
      body: JSON.stringify(ruleData),
    });
  }

  async deleteRule(ruleId) {
    return this.request(`/rules/${ruleId}`, {
      method: 'DELETE',
    });
  }

  async validateRules(datasetId, rules) {
    return this.request('/rule-validation/', {
      method: 'POST',
      body: JSON.stringify({ dataset_id: datasetId, rules }),
    });
  }

  // Dataset validation
  async validateDataset(file, ruleSetId) {
    const formData = new FormData();
    formData.append('file', file);
    formData.append('rule_set_id', ruleSetId);
    
    return this.request('/validate/', {
      method: 'POST',
      headers: {}, // Remove Content-Type to let browser set it with boundary
      body: formData,
    });
  }

  // Profiling operations
  async profileDataset(datasetId) {
    return this.request('/profile/', {
      method: 'POST',
      body: JSON.stringify({ dataset_id: datasetId }),
    });
  }

  async getProfile(datasetId) {
    return this.request(`/profile/${datasetId}`);
  }

  // Application of rules
  async applyRules(file, ruleSetId, selectedRuleIds = []) {
    const formData = new FormData();
    formData.append('file', file);
    formData.append('rule_set_id', ruleSetId);
    
    // Convert selected rule IDs to comma-separated string
    if (selectedRuleIds && selectedRuleIds.length > 0) {
      formData.append('rule_ids', selectedRuleIds.join(','));
    }
    
    return this.request('/apply/', {
      method: 'POST',
      headers: {}, // Remove Content-Type to let browser set it with boundary
      body: formData,
    });
  }

  async getApplyResults(jobId) {
    return this.request(`/apply/${jobId}`);
  }

  // Feedback operations
  async submitFeedback(feedbackData) {
    return this.request('/feedback/', {
      method: 'POST',
      body: JSON.stringify(feedbackData),
    });
  }

  // Health check
  async healthCheck() {
    return this.request('/health');
  }
}

export const api = new APIClient();
