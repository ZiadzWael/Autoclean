import React from 'react';
import ReactDOM from 'react-dom/client';
import App from './App';
import './index.css';

// Error Boundary Component
class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false, error: null, errorInfo: null };
  }

  static getDerivedStateFromError(error) {
    return { hasError: true };
  }

  componentDidCatch(error, errorInfo) {
    this.setState({
      error: error,
      errorInfo: errorInfo
    });
    
    // Log error to analytics service
    console.error('Application Error:', error, errorInfo);
    
    // In production, send to error tracking service
    if (import.meta.env.MODE === 'production') {
      // Example: sendToErrorTracking(error, errorInfo);
    }
  }

  render() {
    if (this.state.hasError) {
      return (
        <div style={{
          minHeight: '100vh',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          background: 'linear-gradient(135deg, #f5f5f5 0%, #e0e0e0 100%)',
          padding: '2rem'
        }}>
          <div style={{
            background: 'white',
            borderRadius: '12px',
            padding: '3rem',
            maxWidth: '600px',
            boxShadow: '0 4px 20px rgba(0, 0, 0, 0.1)',
            textAlign: 'center'
          }}>
            <div style={{
              fontSize: '4rem',
              marginBottom: '1rem'
            }}>
              ✨
            </div>
            <h1 style={{
              fontSize: '1.5rem',
              color: '#212121',
              marginBottom: '1rem'
            }}>
              Something went wrong
            </h1>
            <p style={{
              color: '#666',
              marginBottom: '2rem',
              lineHeight: '1.6'
            }}>
              We apologize for the inconvenience. The application has encountered an error.
            </p>
            <div style={{
              background: '#ffebee',
              padding: '1rem',
              borderRadius: '8px',
              marginBottom: '2rem',
              textAlign: 'left',
              fontFamily: 'monospace',
              fontSize: '0.875rem'
            }}>
              <div style={{ color: '#c62828', marginBottom: '0.5rem' }}>
                {this.state.error && this.state.error.toString()}
              </div>
            </div>
            <button
              onClick={() => window.location.reload()}
              style={{
                background: 'linear-gradient(135deg, #2196f3 0%, #1976d2 100%)',
                color: 'white',
                border: 'none',
                padding: '0.75rem 1.5rem',
                borderRadius: '8px',
                fontWeight: '600',
                cursor: 'pointer',
                fontSize: '1rem'
              }}
            >
              Reload Application
            </button>
          </div>
        </div>
      );
    }

    return this.props.children;
  }
}

// Performance monitoring
const measurePerformance = () => {
  if (typeof window !== 'undefined' && 'performance' in window) {
    const [pageNav] = performance.getEntriesByType('navigation');
    
    if (pageNav) {
      const metrics = {
        'DOM Load Time': `${pageNav.domContentLoadedEventEnd - pageNav.startTime}ms`,
        'Full Load Time': `${pageNav.loadEventEnd - pageNav.startTime}ms`,
        'First Contentful Paint': performance.getEntriesByName('first-contentful-paint')[0]?.startTime || 'N/A'
      };
      
      console.log('Performance Metrics:', metrics);
      
      // Send to analytics in production
      if (import.meta.env.MODE === 'production') {
        // Example: sendToAnalytics('performance_metrics', metrics);
      }
    }
  }
};

// Real-time WebSocket manager
class WebSocketManager {
  constructor() {
    this.ws = null;
    this.listeners = new Set();
    this.reconnectAttempts = 0;
    this.maxReconnectAttempts = 5;
  }

  connect(url) {
    try {
      this.ws = new WebSocket(url);
      
      this.ws.onopen = () => {
        console.log('WebSocket connected');
        this.reconnectAttempts = 0;
        this.notifyListeners('connected');
      };

      this.ws.onmessage = (event) => {
        const data = JSON.parse(event.data);
        this.notifyListeners('message', data);
      };

      this.ws.onclose = () => {
        console.log('WebSocket disconnected');
        this.notifyListeners('disconnected');
        
        // Attempt to reconnect
        if (this.reconnectAttempts < this.maxReconnectAttempts) {
          this.reconnectAttempts++;
          setTimeout(() => this.connect(url), 3000);
        }
      };

      this.ws.onerror = (error) => {
        console.error('WebSocket error:', error);
        this.notifyListeners('error', error);
      };
    } catch (error) {
      console.error('Failed to connect WebSocket:', error);
    }
  }

  addListener(callback) {
    this.listeners.add(callback);
    return () => this.listeners.delete(callback);
  }

  notifyListeners(event, data) {
    this.listeners.forEach(listener => listener(event, data));
  }

  send(data) {
    if (this.ws && this.ws.readyState === WebSocket.OPEN) {
      this.ws.send(JSON.stringify(data));
    }
  }

  disconnect() {
    if (this.ws) {
      this.ws.close();
      this.ws = null;
    }
    this.listeners.clear();
  }
}

// Global WebSocket instance
export const webSocketManager = new WebSocketManager();

// Application bootstrap
const initializeApp = () => {
  // Set up theme
  const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
  if (prefersDark) {
    document.documentElement.setAttribute('data-theme', 'dark');
  }

  // Measure initial performance
  measurePerformance();

  // Initialize WebSocket connection for real-time features
  if (import.meta.env.VITE_WS_URL) {
    webSocketManager.connect(import.meta.env.VITE_WS_URL);
  }

  // Register service worker for PWA capabilities
  if ('serviceWorker' in navigator && import.meta.env.MODE === 'production') {
    window.addEventListener('load', () => {
      navigator.serviceWorker.register('/service-worker.js').then(
        registration => {
          console.log('ServiceWorker registered:', registration);
        },
        error => {
          console.log('ServiceWorker registration failed:', error);
        }
      );
    });
  }

  // Set up offline detection
  window.addEventListener('online', () => {
    console.log('Application is online');
    document.body.classList.remove('offline');
  });

  window.addEventListener('offline', () => {
    console.log('Application is offline');
    document.body.classList.add('offline');
  });
};

// Create root and render application
const rootElement = document.getElementById('root');

if (!rootElement) {
  console.error('Root element not found! Make sure you have a div with id="root" in your HTML.');
  
  // Create root element if it doesn't exist
  const rootDiv = document.createElement('div');
  rootDiv.id = 'root';
  document.body.appendChild(rootDiv);
}

try {
  // Initialize app configuration
  initializeApp();

  // Create React root
  const root = ReactDOM.createRoot(rootElement);

  // Render application with error boundary
  root.render(
    <React.StrictMode>
      <ErrorBoundary>
        <App />
      </ErrorBoundary>
    </React.StrictMode>
  );

  // Log app initialization
  console.log('AutoClean Application Started');
  console.log('Environment:', import.meta.env.MODE);
  console.log('React Version:', React.version);

} catch (error) {
  console.error('Failed to bootstrap application:', error);
  
  // Fallback rendering for critical errors
  rootElement.innerHTML = `
    <div style="
      min-height: 100vh;
      display: flex;
      align-items: center;
      justify-content: center;
      background: linear-gradient(135deg, #f5f5f5 0%, #e0e0e0 100%);
      padding: 2rem;
      text-align: center;
    ">
      <div style="
        background: white;
        border-radius: 12px;
        padding: 3rem;
        max-width: 500px;
        box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
      ">
        <div style="font-size: 4rem; margin-bottom: 1rem;">✨</div>
        <h1 style="color: #212121; margin-bottom: 1rem;">AutoClean</h1>
        <p style="color: #666; margin-bottom: 2rem;">
          Professional Data Cleaning & Validation System
        </p>
        <p style="color: #f44336; margin-bottom: 2rem;">
          Application failed to start. Please refresh the page.
        </p>
        <button 
          onclick="window.location.reload()"
          style="
            background: linear-gradient(135deg, #2196f3 0%, #1976d2 100%);
            color: white;
            border: none;
            padding: 0.75rem 1.5rem;
            border-radius: 8px;
            font-weight: 600;
            cursor: pointer;
            font-size: 1rem;
          "
        >
          Try Again
        </button>
      </div>
    </div>
  `;
}

// Global error handler
window.addEventListener('error', (event) => {
  console.error('Global Error:', event.error);
  
  // Send to error tracking service in production
  if (import.meta.env.MODE === 'production') {
    // Example: sendToErrorTracking(event.error);
  }
});

// Unhandled promise rejection handler
window.addEventListener('unhandledrejection', (event) => {
  console.error('Unhandled Promise Rejection:', event.reason);
  
  // Send to error tracking service in production
  if (import.meta.env.MODE === 'production') {
    // Example: sendToErrorTracking(event.reason);
  }
});

// Export for testing (ErrorBoundary only - functions break Fast Refresh)
export { ErrorBoundary, initializeApp };