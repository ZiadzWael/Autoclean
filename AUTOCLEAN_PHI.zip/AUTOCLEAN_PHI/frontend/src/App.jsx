import React, { useState, useEffect, useCallback, useMemo, useRef } from 'react';
import { Bar, Doughnut, Line } from 'react-chartjs-2';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend,
  ArcElement,
  PointElement,
  LineElement
} from 'chart.js';
import './App.css';

// Register ChartJS components
ChartJS.register(
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend,
  ArcElement,
  PointElement,
  LineElement
);

// Custom Components
const LoadingOverlay = ({ message = "Processing..." }) => (
  <div className="loading-overlay">
    <div className="loading-spinner"></div>
    <div className="loading-message">{message}</div>
  </div>
);

const StepIndicator = ({ currentStep, totalSteps = 5 }) => {
  const steps = [
    { number: 1, label: "Upload Dataset" },
    { number: 2, label: "Extract Rules" },
    { number: 3, label: "Manage Rules" },
    { number: 4, label: "Validate" },
    { number: 5, label: "Apply & Review" }
  ];

  return (
    <div className="progress-indicator">
      <div className="progress-content">
        <div className="progress-step">
          <span className="progress-step-number">{currentStep}</span>
          <span>
            Step {currentStep} of {totalSteps}
            <span className="text-muted ml-2">— {steps[currentStep - 1].label}</span>
          </span>
        </div>
        <div className="progress-bar">
          <div 
            className="progress-fill" 
            style={{ width: `${(currentStep / totalSteps) * 100}%` }}
          ></div>
        </div>
        <div className="font-semibold">
          {Math.round((currentStep / totalSteps) * 100)}% Complete
        </div>
      </div>
    </div>
  );
};

const WebSocketStatus = ({ connection }) => {
  const getStatusClass = (status) => {
    switch(status) {
      case 'connected': return 'connected';
      case 'connecting': return 'connecting';
      default: return 'disconnected';
    }
  };

  return (
    <div className="flex items-center gap-4">
      <div className={`websocket-status ${getStatusClass(connection)}`}>
        <span className="real-time-badge">●</span>
        {connection === 'connected' ? 'Live' : 
         connection === 'connecting' ? 'Connecting' : 'Offline'}
      </div>
    </div>
  );
};

const LivePreview = ({ data, modifications }) => {
  if (!data || data.length === 0) return null;

  const modificationsMap = useMemo(() => {
    const map = {};
    modifications.forEach(mod => {
      const key = `${mod.row_index}_${mod.column}`;
      map[key] = mod;
    });
    return map;
  }, [modifications]);

  return (
    <div className="live-preview">
      <div className="flex items-center justify-between mb-4">
        <h3>Live Preview</h3>
        <span className="text-sm text-muted">{modifications.length} modifications detected</span>
      </div>
      <div className="preview-grid">
        {data.slice(0, 10).map((row, idx) => (
          <div 
            key={idx} 
            className={`preview-row ${modifications.some(m => m.row_index === idx) ? 'modified' : ''}`}
          >
            {Object.entries(row).slice(0, 5).map(([key, value], colIdx) => {
              const modKey = `${idx}_${key}`;
              const modification = modificationsMap[modKey];
              
              return (
                <div key={colIdx} className="flex flex-col">
                  <div className="text-xs text-muted mb-1">{key}</div>
                  {modification ? (
                    <div className="flex gap-1">
                      <div className="preview-cell old-value flex-1">
                        {String(modification.old_value).substring(0, 20)}
                      </div>
                      <div className="preview-cell new-value flex-1">
                        {String(modification.new_value).substring(0, 20)}
                      </div>
                    </div>
                  ) : (
                    <div className="preview-cell">
                      {String(value).substring(0, 30)}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        ))}
      </div>
    </div>
  );
};

const AnalyticsDashboard = ({ metrics, modifications, rules, violationsBefore, violationsAfter }) => {
  const rulePerformanceData = useMemo(() => {
    const ruleStats = {};
    modifications.forEach(mod => {
      const ruleId = mod.rule_id;
      if (!ruleStats[ruleId]) {
        ruleStats[ruleId] = { modifications: 0, rule: rules.find(r => r.id === ruleId) };
      }
      ruleStats[ruleId].modifications++;
    });

    return {
      labels: Object.values(ruleStats).map(s => s.rule?.type || 'Unknown').slice(0, 10),
      datasets: [{
        label: 'Modifications',
        data: Object.values(ruleStats).map(s => s.modifications).slice(0, 10),
        backgroundColor: 'rgba(33, 150, 243, 0.7)',
        borderColor: 'rgb(33, 150, 243)',
        borderWidth: 1
      }]
    };
  }, [modifications, rules]);

  const trendData = useMemo(() => {
    const timeStamps = ['Start', '25%', '50%', '75%', 'Complete'];
    const qualityScores = [65, 72, 78, 85, metrics?.cleaned_quality_score * 100 || 90];
    
    return {
      labels: timeStamps,
      datasets: [{
        label: 'Quality Score',
        data: qualityScores,
        borderColor: 'rgb(76, 175, 80)',
        backgroundColor: 'rgba(76, 175, 80, 0.1)',
        fill: true,
        tension: 0.4
      }]
    };
  }, [metrics]);

  const impactData = useMemo(() => {
    const before = violationsBefore.reduce((sum, v) => sum + (v.count || 0), 0);
    const after = violationsAfter.reduce((sum, v) => sum + (v.count || 0), 0);
    
    return {
      labels: ['Violations Removed', 'Remaining Violations'],
      datasets: [{
        data: [before - after, after],
        backgroundColor: [
          'rgba(76, 175, 80, 0.7)',
          'rgba(244, 67, 54, 0.7)'
        ]
      }]
    };
  }, [violationsBefore, violationsAfter]);

  return (
    <div className="analytics-dashboard">
      <h2>Advanced Analytics Dashboard</h2>
      <div className="analytics-grid">
        <div className="analytics-card">
          <div className="analytics-header">
            <div className="analytics-title">Rule Performance</div>
          </div>
          <Bar 
            data={rulePerformanceData}
            options={{
              responsive: true,
              maintainAspectRatio: true,
              plugins: {
                legend: { display: false }
              }
            }}
          />
        </div>
        
        <div className="analytics-card">
          <div className="analytics-header">
            <div className="analytics-title">Quality Trends</div>
          </div>
          <Line 
            data={trendData}
            options={{
              responsive: true,
              maintainAspectRatio: true,
              scales: {
                y: {
                  beginAtZero: false,
                  min: 50,
                  max: 100,
                  ticks: {
                    callback: value => `${value}%`
                  }
                }
              }
            }}
          />
        </div>
        
        <div className="analytics-card">
          <div className="analytics-header">
            <div className="analytics-title">Impact Analysis</div>
          </div>
          <Doughnut 
            data={impactData}
            options={{
              responsive: true,
              maintainAspectRatio: true,
              plugins: {
                legend: {
                  position: 'bottom'
                }
              }
            }}
          />
        </div>
      </div>
    </div>
  );
};

const TeamCollaboration = ({ ruleSetId, rules }) => {
  const [teamMembers, setTeamMembers] = useState([
    { id: 1, name: 'Alex Johnson', role: 'Data Scientist', avatar: 'AJ' },
    { id: 2, name: 'Maria Garcia', role: 'Data Engineer', avatar: 'MG' },
    { id: 3, name: 'David Chen', role: 'Analyst', avatar: 'DC' }
  ]);
  
  const [sharedRuleSets, setSharedRuleSets] = useState([
    { id: 1, name: 'Customer Data Rules', owner: 'Alex Johnson', sharedDate: '2026-01-15' },
    { id: 2, name: 'Sales Data Standards', owner: 'Maria Garcia', sharedDate: '2026-01-10' }
  ]);

  const shareRuleSet = async (userIds) => {
    // API call to share rule set
    console.log('Sharing rule set with:', userIds);
  };

  return (
    <div className="collaboration-panel">
      <h2>Team Collaboration</h2>
      
      <div className="mt-6">
        <h3>Team Members</h3>
        <div className="team-members">
          {teamMembers.map(member => (
            <div key={member.id} className="team-member-card">
              <div className="member-avatar">{member.avatar}</div>
              <div>
                <div className="font-semibold">{member.name}</div>
                <div className="text-sm text-muted">{member.role}</div>
              </div>
            </div>
          ))}
        </div>
      </div>

      <div className="mt-8">
        <div className="flex items-center justify-between mb-4">
          <h3>Shared Rule Sets</h3>
          <button className="button button-sm">
            Share Current Rules
          </button>
        </div>
        
        <div className="shared-rule-sets">
          {sharedRuleSets.map(ruleSet => (
            <div key={ruleSet.id} className="shared-rule-set">
              <div className="flex items-center justify-between">
                <div>
                  <div className="font-semibold">{ruleSet.name}</div>
                  <div className="text-sm text-muted">
                    Shared by {ruleSet.owner} • {ruleSet.sharedDate}
                  </div>
                </div>
                <button className="button button-sm button-outline">
                  Import
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

const RuleVersionControl = ({ ruleId, versions = [] }) => {
  const [currentVersion, setCurrentVersion] = useState(0);
  
  const versionHistory = [
    { id: 1, version: 3, author: 'Alex Johnson', timestamp: '2026-01-20 14:30', changes: 'Optimized threshold values' },
    { id: 2, version: 2, author: 'Maria Garcia', timestamp: '2026-01-19 11:15', changes: 'Added new domain values' },
    { id: 3, version: 1, author: 'David Chen', timestamp: '2026-01-18 09:45', changes: 'Initial rule creation' }
  ];

  const revertToVersion = async (version) => {
    // API call to revert to version
    console.log('Reverting to version:', version);
    setCurrentVersion(version);
  };

  return (
    <div className="version-control">
      <h3>Version History</h3>
      <div className="version-timeline">
        {versionHistory.map(version => (
          <div 
            key={version.id} 
            className={`version-item ${version.version === currentVersion ? 'active' : ''}`}
          >
            <div className="version-meta">
              <div className="font-semibold">Version {version.version}</div>
              <div className="text-sm text-muted">
                {version.author} • {version.timestamp}
              </div>
              <div className="text-sm mt-1">{version.changes}</div>
            </div>
            <button 
              className="button button-sm button-outline"
              onClick={() => revertToVersion(version.version)}
            >
              Restore
            </button>
          </div>
        ))}
      </div>
    </div>
  );
};

const MetricCard = ({ label, value, delta, icon }) => (
  <div className="metric-card">
    <div className="text-muted text-sm font-medium">{label}</div>
    <div className="metric-value">{value}</div>
    {delta && (
      <div className={`metric-delta ${delta > 0 ? 'positive' : 'negative'}`}>
        {delta > 0 ? '↗' : '↘'} {Math.abs(delta)}
      </div>
    )}
    <div className="text-2xl mt-3">{icon}</div>
  </div>
);

const RuleCard = ({ rule, isSelected, onToggle, onDelete }) => {
  const getConfidenceClass = (score) => {
    if (score >= 0.8) return 'high';
    if (score >= 0.6) return 'medium';
    return 'low';
  };

  return (
    <div className={`rule-card ${isSelected ? 'selected' : ''}`}>
      <div className="flex items-center gap-3">
        <div className="checkbox-group">
          <div 
            className={`checkbox ${isSelected ? 'checked' : ''}`}
            onClick={() => onToggle(rule.id)}
          >
            {isSelected && '✓'}
          </div>
        </div>
        
        <div className="flex-1">
          <div className="rule-header">
            <div className="flex items-center gap-3">
              <span className="rule-id">{rule.id}</span>
              <span className="rule-type">
                Type: {rule.type}
              </span>
              {rule.column && (
                <span className="rule-type">
                  Column: {rule.column}
                </span>
              )}
            </div>
            
            {rule.confidence_score !== undefined && (
              <div className={`rule-confidence ${getConfidenceClass(rule.confidence_score)}`}>
                {Math.round(rule.confidence_score * 100)}%
              </div>
            )}
          </div>

          {rule.reasoning && (
            <div className="rule-reasoning">
              {rule.reasoning}
            </div>
          )}

          <div className="flex flex-wrap gap-2 mt-3">
            {rule.domain && (
              <span className="text-xs px-2 py-1 bg-purple-100 text-purple-800 rounded-full">
                Domain: {rule.domain}
              </span>
            )}
            {rule.determinant && (
              <span className="text-xs px-2 py-1 bg-blue-100 text-blue-800 rounded-full">
                {rule.determinant} → {rule.dependent}
              </span>
            )}
            {rule.values && (
              <span className="text-xs px-2 py-1 bg-green-100 text-green-800 rounded-full">
                {rule.values.length} values
              </span>
            )}
          </div>
        </div>

        <button
          onClick={() => onDelete(rule.id)}
          className="button button-sm button-outline"
          data-tooltip="Delete rule"
        >
          Delete
        </button>
      </div>
    </div>
  );
};

const FileUploadCard = ({ file, onFileChange, onSubmit, loading }) => (
  <div className="section">
    <div className="section-header">
      <div className="section-icon">✨</div>
      <div>
        <h2>Dataset Upload</h2>
        <p className="text-muted">
          Start by uploading your CSV or JSON dataset. Our AI system will analyze it for data quality issues.
        </p>
      </div>
    </div>

    <div className="card">
      <form onSubmit={onSubmit}>
        <div className="form-group">
          <label className="form-label">Select Dataset File</label>
          <input
            type="file"
            accept=".csv,.json"
            onChange={onFileChange}
            className="form-control form-control-file"
            disabled={loading}
          />
          {file && (
            <div className="file-selected">
              <span className="file-selected-icon">✓</span>
              <div>
                <div className="font-semibold">{file.name}</div>
                <div className="text-sm text-muted">
                  {(file.size / 1024 / 1024).toFixed(2)} MB • {file.type}
                </div>
              </div>
            </div>
          )}
        </div>

        <button 
          type="submit" 
          className="button button-lg w-full"
          disabled={!file || loading}
        >
          <span className="button-content">
            Upload Dataset
          </span>
        </button>
      </form>
    </div>
  </div>
);

/**
 * AutoClean - Professional Data Cleaning System
 */
function App() {
  // Application state
  const [datasetId, setDatasetId] = useState(null);
  const [ruleSetId, setRuleSetId] = useState(null);
  const [file, setFile] = useState(null);
  const [rules, setRules] = useState([]);
  const [selectedRuleIds, setSelectedRuleIds] = useState([]);
  const [violations, setViolations] = useState([]);
  const [cleaned, setCleaned] = useState([]);
  const [modifications, setModifications] = useState([]);
  const [step, setStep] = useState(1);
  const [selectedExtractors, setSelectedExtractors] = useState([]);
  const [conflicts, setConflicts] = useState([]);
  const [metrics, setMetrics] = useState(null);
  const [violationsBefore, setViolationsBefore] = useState([]);
  const [violationsAfter, setViolationsAfter] = useState([]);
  const [loading, setLoading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [websocketStatus, setWebsocketStatus] = useState('disconnected');
  const [realTimeUpdates, setRealTimeUpdates] = useState([]);
  const wsRef = useRef(null);
  const wsReconnectAttempts = useRef(0);
  const maxReconnectAttempts = 5;

  // WebSocket setup
  useEffect(() => {
    const setupWebSocket = () => {
      try {
        // Connect to backend WebSocket server on port 8001
        const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
        const wsUrl = `${protocol}//localhost:8001/ws`;
        
        const ws = new WebSocket(wsUrl);
        wsRef.current = ws;

        ws.onopen = () => {
          console.log('✓ WebSocket connected');
          setWebsocketStatus('connected');
          wsReconnectAttempts.current = 0;
          
          // Send ping to keep connection alive
          ws.send(JSON.stringify({ type: 'ping' }));
        };

        ws.onmessage = (event) => {
          try {
            const data = JSON.parse(event.data);
            
            if (data.type === 'pong') {
              // Connection is alive
            } else if (data.type === 'progress_update') {
              setRealTimeUpdates(prev => [...prev.slice(-9), data]);
              console.log('Progress:', data.message);
            } else if (data.type === 'extraction_complete') {
              console.log(`✓ Extraction complete: ${data.rule_count} rules`);
              setRealTimeUpdates(prev => [...prev, data]);
            } else if (data.type === 'validation_complete') {
              console.log(`✓ Validation complete: ${data.violation_count} violations`);
              setRealTimeUpdates(prev => [...prev, data]);
            } else if (data.type === 'error') {
              console.error('Server error:', data.message);
              setRealTimeUpdates(prev => [...prev, data]);
            }
          } catch (e) {
            console.warn('Message parse error:', e);
          }
        };

        ws.onclose = () => {
          console.log('WebSocket disconnected');
          setWebsocketStatus('disconnected');
          // Attempt to reconnect after 5 seconds if under max attempts
          if (wsReconnectAttempts.current < maxReconnectAttempts) {
            wsReconnectAttempts.current += 1;
            console.log(`Attempting to reconnect... (${wsReconnectAttempts.current}/${maxReconnectAttempts})`);
            setTimeout(setupWebSocket, 5000);
          }
        };

        ws.onerror = (error) => {
          console.error('WebSocket error:', error);
          setWebsocketStatus('disconnected');
        };
      } catch (error) {
        console.error('Failed to setup WebSocket:', error);
      }
    };

    setupWebSocket();

    return () => {
      if (wsRef.current) {
        wsRef.current.close();
      }
    };
  }, []);

  // Handle dataset upload
  const handleUpload = async (e) => {
    e.preventDefault();
    if (!file) return;
    
    setLoading(true);
    setUploadProgress(0);
    
    try {
      const formData = new FormData();
      formData.append('file', file);
      
      const res = await fetch('/ingest/', {
        method: 'POST',
        body: formData,
      });
      
      if (!res.ok) {
        throw new Error(`Upload failed: ${res.statusText}`);
      }
      
      const data = await res.json();
      setDatasetId(data.dataset_id);
      
      // Send WebSocket notification
      if (wsRef.current?.readyState === WebSocket.OPEN) {
        wsRef.current.send(JSON.stringify({
          type: 'upload_complete',
          dataset_id: data.dataset_id
        }));
      }
      
      setStep(2);
    } catch (error) {
      console.error('Upload error:', error);
      alert(`Error uploading dataset: ${error.message}`);
    } finally {
      setLoading(false);
      setUploadProgress(0);
    }
  };

  // Extract rules from the uploaded file
  const handleExtract = async () => {
    if (!file) return;
    setLoading(true);
    
    try {
      const formData = new FormData();
      formData.append('file', file);
      
      const res = await fetch('/extract/', {
        method: 'POST',
        body: formData,
      });
      
      if (!res.ok) {
        const errorText = await res.text();
        console.error('Backend error response:', errorText);
        throw new Error(`Backend returned ${res.status}: ${errorText}`);
      }
      
      let data;
      try {
        data = await res.json();
      } catch (parseError) {
        console.error('Failed to parse response as JSON:', parseError);
        console.error('Response text:', await res.text());
        throw new Error(`Invalid JSON from backend: ${parseError.message}`);
      }
      
      setRuleSetId(data.rule_set_id);
      setRules(data.rules || []);
      setSelectedExtractors(data.selected_extractors || []);
      setConflicts(data.conflicts || []);
      
      // Initialize selected rule IDs to all rules
      setSelectedRuleIds((data.rules || []).map((r) => r.id));
      
      // Send WebSocket notification
      if (wsRef.current?.readyState === WebSocket.OPEN) {
        wsRef.current.send(JSON.stringify({
          type: 'extraction_complete',
          rule_count: data.rules?.length || 0
        }));
      }
      
      setStep(3);
    } catch (error) {
      console.error('Extraction error:', error);
      alert(`Error extracting rules: ${error.message}`);
    } finally {
      setLoading(false);
    }
  };

  // Validate the uploaded file against the extracted rules
  const handleValidate = async () => {
    if (!file || !ruleSetId) return;
    setLoading(true);
    
    try {
      const formData = new FormData();
      formData.append('file', file);
      formData.append('rule_set_id', ruleSetId);
      
      const res = await fetch('/validate/', {
        method: 'POST',
        body: formData,
      });
      
      if (!res.ok) {
        throw new Error(`Validation failed: ${res.statusText}`);
      }
      
      const data = await res.json();
      setViolations(data.violations || []);
      
      // Send WebSocket notification
      if (wsRef.current?.readyState === WebSocket.OPEN) {
        const violationCount = data.violations?.reduce((sum, v) => sum + (v.count || 0), 0) || 0;
        wsRef.current.send(JSON.stringify({
          type: 'validation_complete',
          violation_count: violationCount
        }));
      }
      
      setStep(4);
    } catch (error) {
      console.error('Validation error:', error);
      alert(`Error validating dataset: ${error.message}`);
    } finally {
      setLoading(false);
    }
  };

  // Apply the rules to clean the dataset
  const handleApply = async () => {
    if (!file || !ruleSetId) return;
    setLoading(true);
    
    try {
      const formData = new FormData();
      formData.append('file', file);
      formData.append('rule_set_id', ruleSetId);
      
      if (selectedRuleIds && selectedRuleIds.length > 0) {
        formData.append('rule_ids', selectedRuleIds.join(','));
      }
      
      const res = await fetch('/apply/', {
        method: 'POST',
        body: formData,
      });
      
      const data = await res.json();
      setCleaned(data.cleaned || []);
      setModifications(data.modifications || []);
      setMetrics(data.metrics || null);
      setViolationsBefore(data.violations_before || []);
      setViolationsAfter(data.violations_after || []);
      
      if (data.rules) {
        setRules(data.rules);
      }
      
      // Send WebSocket notification
      if (wsRef.current?.readyState === WebSocket.OPEN) {
        wsRef.current.send(JSON.stringify({
          type: 'cleaning_complete',
          modifications: data.modifications?.length || 0,
          quality_improvement: data.metrics?.quality_improvement || 0
        }));
      }
      
      setStep(5);
    } catch (error) {
      console.error('Application error:', error);
      alert(`Error applying rules: ${error.message}`);
    } finally {
      setLoading(false);
    }
  };

  // Download cleaned dataset as CSV
  const downloadCSV = useCallback(() => {
    if (!cleaned || cleaned.length === 0) return;
    
    const headers = Object.keys(cleaned[0]);
    const rows = cleaned.map((row) =>
      headers
        .map((h) => {
          const val = row[h];
          return JSON.stringify(val !== undefined ? val : '');
        })
        .join(',')
    );
    
    const csvContent = [headers.join(',')].concat(rows).join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', 'cleaned_dataset.csv');
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  }, [cleaned]);

  // Download cleaned dataset as Excel
  const downloadExcel = async () => {
    if (!cleaned || cleaned.length === 0) return;
    
    try {
      const XLSX = await import('xlsx');
      const ws = XLSX.utils.json_to_sheet(cleaned);
      const wb = XLSX.utils.book_new();
      XLSX.utils.book_append_sheet(wb, ws, 'Cleaned');
      const wbout = XLSX.write(wb, { bookType: 'xlsx', type: 'array' });
      const blob = new Blob([wbout], { 
        type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' 
      });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = 'cleaned_dataset.xlsx';
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);
    } catch (error) {
      console.error('Excel export error:', error);
      alert('Error exporting to Excel');
    }
  };

  // Compute modifications chart data
  const modificationsChartData = useMemo(() => {
    const counts = {};
    modifications.forEach((mod) => {
      const type = mod.rule_type || 'unknown';
      counts[type] = (counts[type] || 0) + 1;
    });
    
    return {
      labels: Object.keys(counts),
      datasets: [
        {
          label: 'Modifications',
          data: Object.values(counts),
          backgroundColor: [
            'rgba(33, 150, 243, 0.7)',
            'rgba(76, 175, 80, 0.7)',
            'rgba(255, 152, 0, 0.7)',
            'rgba(156, 39, 176, 0.7)',
            'rgba(244, 67, 54, 0.7)',
          ],
          borderColor: [
            'rgb(33, 150, 243)',
            'rgb(76, 175, 80)',
            'rgb(255, 152, 0)',
            'rgb(156, 39, 176)',
            'rgb(244, 67, 54)',
          ],
          borderWidth: 1,
        },
      ],
    };
  }, [modifications]);

  // Compute metrics chart data
  const metricsChartData = useMemo(() => {
    if (!metrics) return null;
    
    return {
      labels: ['Before Cleaning', 'After Cleaning'],
      datasets: [
        {
          label: 'Data Quality Score',
          data: [
            (metrics.original_quality_score || 0) * 100,
            (metrics.cleaned_quality_score || 0) * 100
          ],
          backgroundColor: [
            'rgba(244, 67, 54, 0.7)',
            'rgba(76, 175, 80, 0.7)',
          ],
          borderColor: [
            'rgb(244, 67, 54)',
            'rgb(76, 175, 80)',
          ],
          borderWidth: 2,
        },
      ],
    };
  }, [metrics]);

  // Compute violations reduction data
  const violationsReductionData = useMemo(() => {
    const before = violationsBefore.reduce((sum, v) => sum + (v.count || 0), 0);
    const after = violationsAfter.reduce((sum, v) => sum + (v.count || 0), 0);
    const reduction = before > 0 ? ((before - after) / before) * 100 : 0;
    
    return {
      before,
      after,
      reduction,
      labels: ['Before', 'After'],
      datasets: [
        {
          label: 'Violations',
          data: [before, after],
          backgroundColor: [
            'rgba(244, 67, 54, 0.7)',
            'rgba(76, 175, 80, 0.7)',
          ],
        },
      ],
    };
  }, [violationsBefore, violationsAfter]);

  // Handle rule selection
  const toggleRuleSelection = useCallback((ruleId) => {
    setSelectedRuleIds(prev => 
      prev.includes(ruleId)
        ? prev.filter(id => id !== ruleId)
        : [...prev, ruleId]
    );
  }, []);

  // Handle rule deletion
  const handleDeleteRule = useCallback(async (ruleId) => {
    if (!confirm(`Are you sure you want to delete rule ${ruleId}?`)) return;
    
    try {
      await fetch(`/rules/${ruleSetId}/${ruleId}`, { 
        method: 'DELETE' 
      });
      
      setRules(prev => prev.filter(r => r.id !== ruleId));
      setSelectedRuleIds(prev => prev.filter(id => id !== ruleId));
    } catch (error) {
      console.error('Delete error:', error);
      alert('Error deleting rule');
    }
  }, [ruleSetId]);

  // Select all rules
  const selectAllRules = useCallback(() => {
    setSelectedRuleIds(rules.map(r => r.id));
  }, [rules]);

  // Deselect all rules
  const deselectAllRules = useCallback(() => {
    setSelectedRuleIds([]);
  }, []);

  // Render step content based on current step
  const renderStepContent = () => {
    switch (step) {
      case 1:
        return (
          <FileUploadCard
            file={file}
            onFileChange={(e) => setFile(e.target.files[0])}
            onSubmit={handleUpload}
            loading={loading}
          />
        );
      
      case 2:
        return (
          <div className="section">
            <div className="section-header">
              <div className="section-icon">✨</div>
              <div>
                <h2>AI Rule Extraction</h2>
                <p className="text-muted">
                  Let our AI model intelligently identify data quality rules from your dataset.
                </p>
              </div>
            </div>

            <div className="card">
              <div className="mb-6">
                <h3>GPU-Powered Analysis</h3>
                <p className="text-muted">
                  Our AI will analyze your dataset structure and content to identify patterns,
                  anomalies, and potential data quality rules.
                </p>
              </div>

              <button
                onClick={handleExtract}
                className="button button-lg w-full"
                disabled={!file || loading}
              >
                <span className="button-content">
                  Extract Rules with AI
                </span>
              </button>
            </div>

            {selectedExtractors.length > 0 && (
              <div className="mt-6">
                <h3>Selected Extractors</h3>
                <div className="flex flex-wrap gap-2 mt-3">
                  {selectedExtractors.map((ext, idx) => (
                    <span 
                      key={idx}
                      className="px-3 py-2 bg-primary-100 text-primary-800 rounded-lg font-medium"
                    >
                      {ext.replace(/(find_|extract_)/g, '')}
                    </span>
                  ))}
                </div>
              </div>
            )}

            {conflicts.length > 0 && (
              <div className="mt-6">
                <div className="alert alert-warning">
                  <div className="alert-icon">!</div>
                  <div>
                    <h4>Rule Conflicts Detected</h4>
                    <ul className="mt-2 space-y-1">
                      {conflicts.map((conflict, idx) => (
                        <li key={idx}>
                          <strong>{conflict.type}:</strong> {conflict.message}
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
              </div>
            )}

            {rules.length > 0 && (
              <div className="mt-6">
                <h3>Extracted Rules ({rules.length})</h3>
                <div className="rules-list mt-3">
                  {rules.map((rule) => (
                    <RuleCard
                      key={rule.id}
                      rule={rule}
                      isSelected={selectedRuleIds.includes(rule.id)}
                      onToggle={toggleRuleSelection}
                      onDelete={handleDeleteRule}
                    />
                  ))}
                </div>
              </div>
            )}

            <div className="flex justify-between mt-8">
              <button 
                onClick={() => setStep(1)}
                className="button button-outline"
              >
                Back
              </button>
              <button 
                onClick={() => setStep(3)}
                className="button"
                disabled={rules.length === 0}
              >
                Next
              </button>
            </div>
          </div>
        );
      
      case 3:
        return (
          <div className="section">
            <div className="section-header">
              <div className="section-icon">✨</div>
              <div>
                <h2>Rule Management</h2>
                <p className="text-muted">
                  Fine-tune and manage the extracted rules. Select which ones to apply to your dataset.
                </p>
              </div>
            </div>

            <div className="card">
              <div className="flex items-center justify-between mb-6">
                <div>
                  <h3>Rule Selection</h3>
                  <p className="text-muted text-sm mt-1">
                    {selectedRuleIds.length} of {rules.length} rules selected
                  </p>
                </div>
                <div className="flex gap-2">
                  <button 
                    onClick={selectAllRules}
                    className="button button-sm"
                  >
                    Select All
                  </button>
                  <button 
                    onClick={deselectAllRules}
                    className="button button-sm button-outline"
                  >
                    Deselect All
                  </button>
                </div>
              </div>

              {rules.length === 0 ? (
                <div className="alert alert-info">
                  <div className="alert-icon">!</div>
                  <div>No rules extracted yet. Go back to extract rules from your dataset.</div>
                </div>
              ) : (
                <div className="rules-list">
                  {rules
                    .sort((a, b) => (b.confidence_score || 0) - (a.confidence_score || 0))
                    .map((rule) => (
                      <RuleCard
                        key={rule.id}
                        rule={rule}
                        isSelected={selectedRuleIds.includes(rule.id)}
                        onToggle={toggleRuleSelection}
                        onDelete={handleDeleteRule}
                      />
                    ))}
                </div>
              )}
            </div>

            {rules.length > 0 && (
              <RuleVersionControl 
                ruleId={rules[0]?.id} 
                versions={[]} 
              />
            )}

            <div className="flex justify-between mt-8">
              <button 
                onClick={() => setStep(2)}
                className="button button-outline"
              >
                Back
              </button>
              <button 
                onClick={() => setStep(4)}
                className="button"
                disabled={rules.length === 0}
              >
                Next
              </button>
            </div>
          </div>
        );
      
      case 4:
        return (
          <div className="section">
            <div className="section-header">
              <div className="section-icon">✨</div>
              <div>
                <h2>Dataset Validation</h2>
                <p className="text-muted">
                  Check your dataset for violations against the extracted rules before cleaning.
                </p>
              </div>
            </div>

            <div className="card">
              <div className="mb-6">
                <h3>Validation Preview</h3>
                <p className="text-muted">
                  Validate your dataset against {selectedRuleIds.length} selected rules.
                </p>
              </div>

              <button
                onClick={handleValidate}
                className="button button-lg w-full"
                disabled={!file || !ruleSetId || loading}
              >
                <span className="button-content">
                  Validate Dataset
                </span>
              </button>
            </div>

            {violations.length > 0 ? (
              <div className="mt-6">
                <div className="alert alert-warning">
                  <div className="alert-icon">!</div>
                  <div>
                    <h4>Violations Found</h4>
                    <p className="mt-1">
                      {violations.reduce((sum, v) => sum + (v.count || 0), 0)} total violations detected
                    </p>
                  </div>
                </div>

                <div className="table-container">
                  <table className="table">
                    <thead>
                      <tr>
                        <th>Column</th>
                        <th>Rule Type</th>
                        <th>Violation Count</th>
                        <th>Severity</th>
                      </tr>
                    </thead>
                    <tbody>
                      {violations.map((v, idx) => (
                        <tr key={idx}>
                          <td><code>{v.column}</code></td>
                          <td>{v.type}</td>
                          <td>
                            <span className="font-bold text-error">
                              {v.count}
                            </span>
                          </td>
                          <td>
                            <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                              v.count > 100 ? 'bg-error-100 text-error-800' :
                              v.count > 10 ? 'bg-warning-100 text-warning-800' :
                              'bg-success-100 text-success-800'
                            }`}>
                              {v.count > 100 ? 'High' : v.count > 10 ? 'Medium' : 'Low'}
                            </span>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            ) : violations.length === 0 && ruleSetId ? (
              <div className="mt-6">
                <div className="alert alert-success">
                  <div className="alert-icon">✓</div>
                  <div>
                    <h4>No Violations Found!</h4>
                    <p className="mt-1">Your dataset is clean and passes all validation rules.</p>
                  </div>
                </div>
              </div>
            ) : null}

            <div className="flex justify-between mt-8">
              <button 
                onClick={() => setStep(3)}
                className="button button-outline"
              >
                Back
              </button>
              <button 
                onClick={() => setStep(5)}
                className="button"
                disabled={!ruleSetId}
              >
                Next
              </button>
            </div>
          </div>
        );
      
      case 5:
        return (
          <div className="section">
            <div className="section-header">
              <div className="section-icon">✨</div>
              <div>
                <h2>Apply Rules & Review Results</h2>
                <p className="text-muted">
                  Apply the selected rules to clean your dataset and review comprehensive metrics.
                </p>
              </div>
            </div>

            <div className="card">
              <div className="mb-6">
                <h3>Ready to Clean</h3>
                <p className="text-muted">
                  Apply {selectedRuleIds.length} selected rules to your dataset.
                </p>
              </div>

              <button
                onClick={handleApply}
                className="button button-lg w-full"
                disabled={!file || !ruleSetId || loading}
              >
                <span className="button-content">
                  Apply {selectedRuleIds.length} Rules
                </span>
              </button>
            </div>

            {loading && realTimeUpdates.length > 0 && (
              <div className="mt-6">
                <h3>Real-time Progress</h3>
                <div className="space-y-2">
                  {realTimeUpdates.map((update, idx) => (
                    <div key={idx} className="text-sm text-muted">
                      {update.message}
                    </div>
                  ))}
                </div>
              </div>
            )}

            {modifications.length > 0 && cleaned.length > 0 && (
              <LivePreview 
                data={cleaned} 
                modifications={modifications} 
              />
            )}

            {metrics && (
              <div className="mt-8">
                <h3>Performance Metrics</h3>
                <div className="metrics-grid">
                  <MetricCard
                    label="Quality Improvement"
                    value={`+${((metrics.quality_improvement || 0) * 100).toFixed(1)}%`}
                    delta={metrics.quality_improvement}
                    icon="✨"
                  />
                  <MetricCard
                    label="Total Modifications"
                    value={metrics.total_modifications || 0}
                    icon="✨"
                  />
                  <MetricCard
                    label="Precision"
                    value={`${((metrics.precision || 0) * 100).toFixed(1)}%`}
                    icon="✨"
                  />
                  <MetricCard
                    label="Recall"
                    value={`${((metrics.recall || 0) * 100).toFixed(1)}%`}
                    icon="✨"
                  />
                  <MetricCard
                    label="F1 Score"
                    value={`${((metrics.f1_score || 0) * 100).toFixed(1)}%`}
                    icon="✨"
                  />
                  <MetricCard
                    label="Processing Time"
                    value={`${(metrics.time_taken_seconds || 0).toFixed(2)}s`}
                    icon="✨"
                  />
                </div>

                {metricsChartData && (
                  <div className="chart-container mt-6">
                    <div className="chart-header">
                      <div className="chart-title">Data Quality Improvement</div>
                    </div>
                    <Bar 
                      data={metricsChartData} 
                      options={{
                        responsive: true,
                        maintainAspectRatio: true,
                        scales: {
                          y: {
                            beginAtZero: true,
                            max: 100,
                            ticks: {
                              callback: (value) => `${value}%`
                            }
                          }
                        }
                      }}
                    />
                  </div>
                )}
              </div>
            )}

            {violationsReductionData.before > 0 && (
              <div className="mt-8">
                <h3>Violation Reduction</h3>
                <div className="card">
                  <div className="flex items-center justify-around">
                    <div className="text-center">
                      <div className="text-3xl font-bold text-error">
                        {violationsReductionData.before}
                      </div>
                      <div className="text-sm text-muted">Before</div>
                    </div>
                    <div className="text-2xl text-muted">→</div>
                    <div className="text-center">
                      <div className="text-3xl font-bold text-success">
                        {violationsReductionData.after}
                      </div>
                      <div className="text-sm text-muted">After</div>
                    </div>
                    <div className="text-center">
                      <div className="text-2xl font-bold text-primary">
                        {violationsReductionData.reduction.toFixed(1)}%
                      </div>
                      <div className="text-sm text-muted">Reduction</div>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {metrics && modifications.length > 0 && rules.length > 0 && (
              <AnalyticsDashboard
                metrics={metrics}
                modifications={modifications}
                rules={rules}
                violationsBefore={violationsBefore}
                violationsAfter={violationsAfter}
              />
            )}

            {ruleSetId && rules.length > 0 && (
              <TeamCollaboration
                ruleSetId={ruleSetId}
                rules={rules}
              />
            )}

            {cleaned.length > 0 && (
              <div className="mt-8">
                <h3>Cleaned Dataset Preview</h3>
                <div className="card">
                  <div className="flex justify-between items-center mb-4">
                    <div>
                      <div className="font-semibold">{cleaned.length} rows</div>
                      <div className="text-sm text-muted">
                        {Object.keys(cleaned[0] || {}).length} columns
                      </div>
                    </div>
                    <div className="flex gap-2">
                      <button 
                        onClick={downloadCSV}
                        className="button button-success"
                      >
                        Download CSV
                      </button>
                      <button 
                        onClick={downloadExcel}
                        className="button"
                      >
                        Download Excel
                      </button>
                    </div>
                  </div>
                  
                  <div className="table-container">
                    <table className="table">
                      <thead>
                        <tr>
                          {Object.keys(cleaned[0] || {}).slice(0, 6).map((key) => (
                            <th key={key}>{key}</th>
                          ))}
                          {Object.keys(cleaned[0] || {}).length > 6 && <th>...</th>}
                        </tr>
                      </thead>
                      <tbody>
                        {cleaned.slice(0, 5).map((row, idx) => (
                          <tr key={idx}>
                            {Object.values(row).slice(0, 6).map((val, i) => (
                              <td key={i} className="truncate max-w-[150px]">
                                {String(val).substring(0, 30)}
                              </td>
                            ))}
                            {Object.keys(cleaned[0] || {}).length > 6 && <td>...</td>}
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            )}

            {modifications.length > 0 && (
              <div className="mt-8">
                <h3>Modifications Summary</h3>
                <div className="card">
                  <div className="chart-header">
                    <div className="chart-title">Modifications by Rule Type</div>
                  </div>
                  <Bar 
                    data={modificationsChartData} 
                    options={{
                      responsive: true,
                      maintainAspectRatio: true,
                    }}
                  />
                </div>
              </div>
            )}

            <div className="flex justify-between mt-8">
              <button 
                onClick={() => setStep(4)}
                className="button button-outline"
              >
                Back
              </button>
            </div>
          </div>
        );
      
      default:
        return null;
    }
  };

  return (
    <div className="app-container">
      <div className="container">
        <header className="p-8 text-center border-b border-border">
          <h1>✨ AutoClean</h1>
          <p className="text-muted mt-2">
            Professional Data Cleaning & Validation System
          </p>
          <div className="flex items-center justify-center gap-4 mt-4">
            <WebSocketStatus connection={websocketStatus} />
          </div>
        </header>

        <main className="p-8">
          <StepIndicator currentStep={step} />
          {renderStepContent()}
        </main>

        <footer className="p-4 border-t border-border text-center text-sm text-muted">
          <p>AutoClean v1.0 • AI-Powered Data Cleaning • © 2026</p>
        </footer>
      </div>

      {loading && <LoadingOverlay />}
    </div>
  );
}

export default App;