"""Database models (stub).

In PH1 the database is not used, but this module defines example ORM models
for datasets and rule sets should a relational store be enabled.
"""

from sqlalchemy import Column, Integer, String, Text

from .base import Base


class Dataset(Base):
    """Example dataset metadata model."""

    __tablename__ = "datasets"

    id = Column(Integer, primary_key=True, index=True)
    dataset_id = Column(String, unique=True, index=True)
    filename = Column(String)


class RuleSet(Base):
    """Example rule set metadata model."""

    __tablename__ = "rule_sets"

    id = Column(Integer, primary_key=True, index=True)
    rule_set_id = Column(String, unique=True, index=True)
    content = Column(Text)