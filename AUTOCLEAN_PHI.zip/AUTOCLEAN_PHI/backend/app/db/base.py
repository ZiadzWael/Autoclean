"""SQLAlchemy base and session setup (stub).

PH1 uses flat file storage for datasets and rule sets rather than a relational
database. This module defines a declarative base for future extensions.
"""

from sqlalchemy.orm import declarative_base, sessionmaker
from sqlalchemy import create_engine

DATABASE_URL = "sqlite:///./autoclean.db"

engine = create_engine(DATABASE_URL, connect_args={"check_same_thread": False})
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

Base = declarative_base()