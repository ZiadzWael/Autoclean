"""Aggregate API routers for AutoClean PH1.

This module collects all individual API routers from submodules and exposes a
single `api_router` that can be included in the FastAPI application.
"""

from fastapi import APIRouter

from .health import router as health_router
from .ingest import router as ingest_router
from .extract import router as extract_router
from .validate import router as validate_router
from .apply import router as apply_router
from .feedback import router as feedback_router
from .profile import router as profile_router
from .rules import router as rules_router
from .rule_validation import router as rule_validation_router
from .actions import router as actions_router
from .mapping import router as mapping_router
from .websocket import router as websocket_router

# Compose a single API router to mount onto the main FastAPI app.
api_router = APIRouter()
api_router.include_router(health_router)
api_router.include_router(ingest_router)
api_router.include_router(extract_router)
api_router.include_router(validate_router)
api_router.include_router(apply_router)
api_router.include_router(feedback_router)
api_router.include_router(profile_router)
api_router.include_router(rules_router)
api_router.include_router(rule_validation_router)
api_router.include_router(actions_router)
api_router.include_router(mapping_router)
api_router.include_router(websocket_router)

__all__ = ["api_router"]