"""Alternate validation endpoints.

Provides a convenience endpoint that validates a dataset already stored in the
data storage directory using a rule set identifier. The client specifies
only the dataset identifier and rule set identifier rather than uploading a
new file.
"""

from fastapi import APIRouter, HTTPException, Query
import pandas as pd
from pathlib import Path

from ..config import STORAGE_DIR
from ..services.rule_store import load_rules
from ..services.rule_validator import validate_dataframe

router = APIRouter(prefix="/rule-validation", tags=["validation"])


@router.get("/")
async def validate_stored_dataset(
    dataset_id: str = Query(..., description="Dataset identifier returned by ingestion"),
    rule_set_id: str = Query(..., description="Rule set identifier")
) -> dict[str, object]:
    """Validate a previously ingested dataset against a stored rule set.

    Parameters
    ----------
    dataset_id : str
        Identifier of the stored dataset.
    rule_set_id : str
        Identifier of the rule set.

    Returns
    -------
    dict[str, object]
        A dictionary containing validation results.
    """
    # Find the file matching the dataset_id prefix.
    files = list(Path(STORAGE_DIR).glob(f"{dataset_id}_*"))
    if not files:
        raise HTTPException(status_code=404, detail="Dataset not found")
    file_path = files[0]

    try:
        df = pd.read_csv(file_path)
    except Exception as exc:
        raise HTTPException(status_code=500, detail=f"Failed to read dataset: {exc}") from exc

    try:
        rules = load_rules(rule_set_id)
    except FileNotFoundError as exc:
        raise HTTPException(status_code=404, detail="Rule set not found") from exc

    violations = validate_dataframe(df, rules)
    return {"violations": violations}