"""Dataset validation endpoints.

This module exposes endpoints that validate a dataset against a given set of
data quality rules. The client may upload a new dataset and supply a rule
set identifier to retrieve the corresponding rule definitions.
"""

import io
from fastapi import APIRouter, File, UploadFile, HTTPException, Form
import pandas as pd

from ..services.rule_store import load_rules
from ..services.rule_validator import validate_dataframe

router = APIRouter(prefix="/validate", tags=["validation"])


@router.post("/")
async def validate_dataset(
    file: UploadFile = File(...),
    rule_set_id: str = Form(...)
) -> dict[str, object]:
    """Validate a dataset against a stored rule set.

    Parameters
    ----------
    file : UploadFile
        The dataset file to validate.
    rule_set_id : str
        The identifier of the stored rule set.

    Returns
    -------
    dict[str, object]
        A dictionary containing validation results and violation statistics.
    """
    try:
        contents = await file.read()
        name = file.filename or "dataset.csv"
        if name.endswith(".csv"):
            df = pd.read_csv(io.BytesIO(contents))
        elif name.endswith(".json"):
            df = pd.read_json(io.BytesIO(contents))
        else:
            df = pd.read_csv(io.BytesIO(contents))
    except Exception as exc:
        raise HTTPException(status_code=400, detail=f"Failed to parse file: {exc}") from exc

    try:
        rules = load_rules(rule_set_id)
    except FileNotFoundError as exc:
        raise HTTPException(status_code=404, detail=f"Rule set {rule_set_id} not found") from exc

    violations = validate_dataframe(df, rules)
    return {"violations": violations}