"""WebSocket endpoint for real-time updates in AutoClean PH1.

This module provides WebSocket support for real-time progress updates,
rule extraction status, and data validation results.
"""

from fastapi import APIRouter, WebSocket, WebSocketDisconnect
import json
import logging

logger = logging.getLogger(__name__)
router = APIRouter()

# Track active WebSocket connections
class ConnectionManager:
    def __init__(self):
        self.active_connections: list[WebSocket] = []

    async def connect(self, websocket: WebSocket):
        await websocket.accept()
        self.active_connections.append(websocket)
        logger.info(f"WebSocket client connected. Total connections: {len(self.active_connections)}")

    def disconnect(self, websocket: WebSocket):
        self.active_connections.remove(websocket)
        logger.info(f"WebSocket client disconnected. Total connections: {len(self.active_connections)}")

    async def broadcast(self, message: dict):
        """Send message to all connected clients."""
        disconnected = []
        for connection in self.active_connections:
            try:
                await connection.send_json(message)
            except Exception as e:
                logger.warning(f"Error sending WebSocket message: {e}")
                disconnected.append(connection)
        
        # Remove disconnected clients
        for conn in disconnected:
            self.disconnect(conn)

    async def send_personal(self, websocket: WebSocket, message: dict):
        """Send message to a specific client."""
        try:
            await websocket.send_json(message)
        except Exception as e:
            logger.warning(f"Error sending personal message: {e}")
            self.disconnect(websocket)


# Global connection manager
manager = ConnectionManager()


@router.websocket("/ws")
async def websocket_endpoint(websocket: WebSocket):
    """WebSocket endpoint for real-time updates.
    
    Clients connect here to receive:
    - Progress updates during rule extraction
    - Validation status updates
    - Data cleaning progress
    - Error notifications
    """
    await manager.connect(websocket)
    try:
        while True:
            # Receive messages from client
            data = await websocket.receive_text()
            
            try:
                message = json.loads(data)
                message_type = message.get("type")
                
                if message_type == "ping":
                    # Health check - respond with pong
                    await manager.send_personal(websocket, {"type": "pong", "status": "ok"})
                    
                elif message_type == "subscribe":
                    # Client subscribes to specific event types
                    event_type = message.get("event")
                    await manager.send_personal(websocket, {
                        "type": "subscription_confirmed",
                        "event": event_type,
                        "status": "subscribed"
                    })
                    
                else:
                    logger.warning(f"Unknown message type: {message_type}")
                    
            except json.JSONDecodeError:
                logger.warning(f"Invalid JSON received: {data}")
                await manager.send_personal(websocket, {
                    "type": "error",
                    "message": "Invalid JSON format"
                })
                
    except WebSocketDisconnect:
        manager.disconnect(websocket)
        logger.info("WebSocket client disconnected normally")
    except Exception as e:
        logger.error(f"WebSocket error: {e}")
        manager.disconnect(websocket)


# Helper function to broadcast progress updates
async def broadcast_progress_update(dataset_id: str, stage: str, progress: int, message: str):
    """Broadcast a progress update to all connected clients.
    
    Args:
        dataset_id: ID of the dataset being processed
        stage: Processing stage (e.g., 'extraction', 'validation', 'cleaning')
        progress: Progress percentage (0-100)
        message: Human-readable status message
    """
    await manager.broadcast({
        "type": "progress_update",
        "dataset_id": dataset_id,
        "stage": stage,
        "progress": progress,
        "message": message
    })


async def broadcast_extraction_complete(dataset_id: str, rule_count: int, rules: list):
    """Broadcast rule extraction completion."""
    await manager.broadcast({
        "type": "extraction_complete",
        "dataset_id": dataset_id,
        "rule_count": rule_count,
        "rules": rules
    })


async def broadcast_validation_complete(dataset_id: str, violations: list, stats: dict):
    """Broadcast validation completion."""
    await manager.broadcast({
        "type": "validation_complete",
        "dataset_id": dataset_id,
        "violation_count": len(violations),
        "violations": violations,
        "stats": stats
    })


async def broadcast_error(error_type: str, message: str, details: dict = None):
    """Broadcast an error to all connected clients."""
    await manager.broadcast({
        "type": "error",
        "error_type": error_type,
        "message": message,
        "details": details or {}
    })
