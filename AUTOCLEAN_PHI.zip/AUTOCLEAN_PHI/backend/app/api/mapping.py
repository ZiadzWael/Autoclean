"""Column mapping endpoints.

This module provides endpoints to map dataset columns onto a canonical schema.
In this simplified implementation it returns a pass-through mapping.
"""

from fastapi import APIRouter, HTTPException, Form
import json

router = APIRouter(prefix="/mapping", tags=["mapping"])


@router.post("/")
async def map_columns(mapping: str = Form(...)) -> dict[str, object]:
    """Echo back the provided column mapping.

    Column mapping is represented as a JSON string of source column names to
    canonical column names. In a full implementation this would involve
    ontology matching or fuzzy string matching.

    Parameters
    ----------
    mapping : str
        JSON string mapping source columns to canonical columns.

    Returns
    -------
    dict[str, object]
        The parsed mapping dictionary.
    """
    try:
        mapping_dict = json.loads(mapping)
    except json.JSONDecodeError as exc:
        raise HTTPException(status_code=400, detail=f"Invalid mapping JSON: {exc}") from exc

    return {"mapping": mapping_dict}