"""Health check endpoints for AutoClean PH1.

Provides a simple endpoint to verify that the backend service is running.
"""

from fastapi import APIRouter

router = APIRouter(prefix="/health", tags=["system"])


@router.get("/")
async def read_health() -> dict[str, str]:
    """Return service health status.

    This can be used by orchestration tools or monitoring to ensure the service
    is alive.

    Returns
    -------
    dict[str, str]
        A simple JSON payload indicating the service status.
    """
    return {"status": "ok"}