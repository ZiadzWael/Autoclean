"""Rule management endpoints.

This module provides endpoints for listing and retrieving stored rule sets.
Clients may inspect the contents of a rule set by its identifier.
"""

from pathlib import Path
from fastapi import APIRouter, HTTPException

from ..config import RULES_DIR
from ..services.rule_store import load_rules, update_rule, delete_rule

router = APIRouter(prefix="/rules", tags=["rules"])


@router.get("/")
async def list_rules() -> dict[str, list[str]]:
    """List all available rule set identifiers.

    Returns
    -------
    dict[str, list[str]]
        A list of rule set identifiers found in the rules directory.
    """
    ids = [p.stem for p in Path(RULES_DIR).glob("*.json")]
    return {"rule_sets": ids}


@router.get("/{rule_set_id}")
async def get_rules(rule_set_id: str) -> dict[str, object]:
    """Retrieve a specific rule set by its identifier.

    Parameters
    ----------
    rule_set_id : str
        Identifier of the rule set to load.

    Returns
    -------
    dict[str, object]
        The loaded rule set.
    """
    try:
        rules = load_rules(rule_set_id)
    except FileNotFoundError as exc:
        raise HTTPException(status_code=404, detail="Rule set not found") from exc
    return {"rules": rules}


@router.put("/{rule_set_id}/{rule_id}")
async def update_rule_endpoint(rule_set_id: str, rule_id: str, new_rule: dict) -> dict[str, object]:
    """Update a specific rule within a rule set.

    Clients can replace an existing rule by providing a JSON body with the
    replacement. The ``id`` of the replacement rule must match the path
    parameter ``rule_id``.

    Parameters
    ----------
    rule_set_id : str
        Identifier of the rule set to modify.
    rule_id : str
        Identifier of the rule to replace.
    new_rule : dict
        Replacement rule definition. Must include an ``id`` field.

    Returns
    -------
    dict[str, object]
        The updated list of rules.
    """
    if not isinstance(new_rule, dict) or new_rule.get("id") != rule_id:
        raise HTTPException(status_code=400, detail="Replacement rule must include matching id field")
    try:
        updated = update_rule(rule_set_id, rule_id, new_rule)
    except FileNotFoundError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    except ValueError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    return {"rules": updated}


@router.delete("/{rule_set_id}/{rule_id}")
async def delete_rule_endpoint(rule_set_id: str, rule_id: str) -> dict[str, object]:
    """Delete a rule from a rule set.

    Parameters
    ----------
    rule_set_id : str
        Identifier of the rule set.
    rule_id : str
        Identifier of the rule to delete.

    Returns
    -------
    dict[str, object]
        The remaining rules after deletion.
    """
    try:
        remaining = delete_rule(rule_set_id, rule_id)
    except FileNotFoundError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    except ValueError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    return {"rules": remaining}