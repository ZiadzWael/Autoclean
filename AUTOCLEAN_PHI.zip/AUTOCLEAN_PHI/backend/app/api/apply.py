"""Apply data quality rules to repair a dataset.

This endpoint applies previously extracted rules to an uploaded dataset
and returns a cleaned version. The cleaned dataset is returned as JSON.
"""

import io
import time
from fastapi import APIRouter, File, UploadFile, HTTPException, Form
import pandas as pd

from ..services.rule_store import load_rules
from ..services.apply_engine import apply_rules_to_dataframe
from ..services.metrics import calculate_rule_effectiveness, calculate_precision_recall
from ..services.rule_validator import validate_dataframe

router = APIRouter(prefix="/apply", tags=["apply"])


@router.post("/")
async def apply_rules(
    file: UploadFile = File(...),
    rule_set_id: str = Form(...),
    rule_ids: str | None = Form(None)
) -> dict[str, object]:
    """Apply a stored rule set (or subset) to a dataset.

    Parameters
    ----------
    file : UploadFile
        The dataset file to clean.
    rule_set_id : str
        Identifier of the stored rule set to apply.
    rule_ids : str | None
        Optional comma-separated list of rule identifiers. When provided,
        only the rules with matching IDs will be applied. This allows
        clients to disable certain rules or experiment with subsets
        interactively.

    Returns
    -------
    dict[str, object]
        A dictionary containing the cleaned dataset in record-oriented
        form, the modifications log, and the applied rules.
    """
    try:
        contents = await file.read()
        name = file.filename or "dataset.csv"
        if name.endswith(".csv"):
            df = pd.read_csv(io.BytesIO(contents))
        elif name.endswith(".json"):
            df = pd.read_json(io.BytesIO(contents))
        else:
            df = pd.read_csv(io.BytesIO(contents))
    except Exception as exc:
        raise HTTPException(status_code=400, detail=f"Failed to parse file: {exc}") from exc

    try:
        all_rules = load_rules(rule_set_id)
    except FileNotFoundError as exc:
        raise HTTPException(status_code=404, detail=f"Rule set {rule_set_id} not found") from exc

    # Filter rules if a comma‑separated list of rule IDs is provided.
    if rule_ids:
        selected_ids = {rid.strip() for rid in rule_ids.split(",") if rid.strip()}
        rules = [r for r in all_rules if r.get("id") in selected_ids]
    else:
        rules = all_rules
    
    # Validate rules before applying
    valid_rules = [r for r in rules if r.get("id") and r.get("type")]
    if not valid_rules:
        raise HTTPException(status_code=400, detail="No valid rules found in rule set")
    
    # Calculate violations before cleaning
    violations_before = validate_dataframe(df, valid_rules)
    
    # Apply rules and capture modifications.
    start_time = time.time()
    cleaned_df, modifications = apply_rules_to_dataframe(df, valid_rules)
    time_taken = time.time() - start_time
    
    # Calculate violations after cleaning
    violations_after = validate_dataframe(cleaned_df, valid_rules)
    
    # Calculate metrics
    effectiveness = calculate_rule_effectiveness(df, cleaned_df, rules, modifications)
    precision_recall = calculate_precision_recall(violations_before, violations_after, modifications)
    
    # Convert cleaned DataFrame to a list-of-dicts for easy JSON serialization.
    cleaned_data = cleaned_df.to_dict(orient="records")
    return {
        "cleaned": cleaned_data,
        "modifications": modifications,
        "rules": rules,
        "metrics": {
            **effectiveness,
            **precision_recall,
            "time_taken_seconds": time_taken
        },
        "violations_before": violations_before,
        "violations_after": violations_after
    }