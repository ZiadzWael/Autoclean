"""Dataset ingestion endpoints.

These endpoints accept dataset uploads from the client and persist the data
to the local storage directory. Supported formats currently include CSV and
JSON data. The ingestion layer returns a unique dataset identifier that can
be used in subsequent rule extraction and validation calls.
"""

import io
import traceback
from fastapi import APIRouter, File, UploadFile, HTTPException
import pandas as pd

from ..services.storage import save_dataset

router = APIRouter(prefix="/ingest", tags=["ingest"])


@router.post("/")
async def ingest_dataset(file: UploadFile = File(...)) -> dict[str, object]:
    """Ingest a dataset file into persistent storage.

    The uploaded file is read into a pandas DataFrame and saved to disk
    in the data storage directory. The function returns a unique dataset
    identifier along with the number of rows ingested.

    Parameters
    ----------
    file : UploadFile
        The uploaded dataset file. Supported formats are CSV and JSON.

    Returns
    -------
    dict[str, object]
        A dictionary containing the dataset identifier and basic statistics.
    """
    try:
        contents = await file.read()
        # Determine file format based on filename suffix.
        name = file.filename or "dataset.csv"
        if name.endswith(".csv"):
            df = pd.read_csv(io.BytesIO(contents))
        elif name.endswith(".json"):
            df = pd.read_json(io.BytesIO(contents))
        else:
            # Fall back to CSV parsing for unknown extensions.
            df = pd.read_csv(io.BytesIO(contents))
    except Exception as exc:
        print(f"[INGEST] File parsing error: {exc}")
        traceback.print_exc()
        raise HTTPException(status_code=400, detail=f"Failed to parse file: {exc}") from exc

    try:
        dataset_id = save_dataset(df, name)
    except Exception as exc:
        print(f"[INGEST] Storage error: {exc}")
        traceback.print_exc()
        raise HTTPException(status_code=500, detail=f"Failed to save dataset: {exc}") from exc
    
    print(f"[INGEST] Successfully saved dataset {dataset_id} with {len(df)} rows")
    return {"dataset_id": dataset_id, "rows": int(len(df)), "columns": list(df.columns)}