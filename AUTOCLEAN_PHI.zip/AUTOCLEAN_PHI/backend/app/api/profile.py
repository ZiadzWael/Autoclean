"""Dataset profiling endpoints.

This endpoint exposes the internal profiler used for rule extraction.
Clients can call this directly to inspect column statistics prior to
rule generation.
"""

import io
from fastapi import APIRouter, File, UploadFile, HTTPException
import pandas as pd

from ..services.profiler import profile_dataframe

router = APIRouter(prefix="/profile", tags=["profile"])


@router.post("/")
async def profile_dataset(file: UploadFile = File(...)) -> dict[str, object]:
    """Compute profile statistics for an uploaded dataset.

    Parameters
    ----------
    file : UploadFile
        The dataset file to profile.

    Returns
    -------
    dict[str, object]
        A nested dictionary containing per-column statistics.
    """
    try:
        contents = await file.read()
        name = file.filename or "dataset.csv"
        if name.endswith(".csv"):
            df = pd.read_csv(io.BytesIO(contents))
        elif name.endswith(".json"):
            df = pd.read_json(io.BytesIO(contents))
        else:
            df = pd.read_csv(io.BytesIO(contents))
    except Exception as exc:
        raise HTTPException(status_code=400, detail=f"Failed to parse file: {exc}") from exc

    profile = profile_dataframe(df)
    return {"profile": profile}