"""User feedback endpoints.

These endpoints allow clients to submit feedback on the quality of the
inferred rules and repair suggestions. Feedback is persisted for later
analysis and continuous learning.
"""

from fastapi import APIRouter, HTTPException, Form

from ..services.feedback_engine import save_feedback

router = APIRouter(prefix="/feedback", tags=["feedback"])


@router.post("/")
async def submit_feedback(rule_set_id: str = Form(...), feedback: str = Form(...)) -> dict[str, str]:
    """Record user feedback on a rule set.

    Feedback can be used to refine future rule generation and repair
    suggestions.

    Parameters
    ----------
    rule_set_id : str
        Identifier of the rule set the feedback refers to.
    feedback : str
        Free-form user feedback text.

    Returns
    -------
    dict[str, str]
        Confirmation that the feedback has been recorded.
    """
    try:
        save_feedback(rule_set_id, feedback)
    except Exception as exc:
        raise HTTPException(status_code=500, detail=f"Failed to record feedback: {exc}") from exc

    return {"message": "Feedback recorded"}