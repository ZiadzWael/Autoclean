"""Rule extraction endpoints.

This module defines endpoints for extracting data quality rules from an
uploaded dataset. Rules are inferred heuristically from the column profiles
and saved into the rule store. Now includes LLM-based planning, curation,
conflict detection, and RAG integration.
"""

import io
import traceback
from fastapi import APIRouter, File, UploadFile, HTTPException
import pandas as pd

from ..services.profiler import profile_dataframe
from ..services.rule_extractor import (
    extract_rules_from_profile,
    find_categorical_rules,
    find_regex_rules,
    find_fd_rules,
    find_outlier_rules,
    find_standardize_rules,
    find_inclusion_rules,
    find_approx_fd_rules,
    find_conditional_fd_rules,
    find_missing_pattern_rules,
    find_domain_regex_rules,
)
from ..services.rule_store import save_rules
from ..services.llm.phi3_extractor_planner import Phi3ExtractorPlanner
from ..services.llm.rule_curator import RuleCurator
from ..services.rule_conflict_detector import detect_conflicts, resolve_conflicts
from ..services.rule_scorer import rank_rules, filter_low_confidence_rules
from ..services.rag.retriever import Retriever
from ..services.finance_rules import extract_finance_rules

router = APIRouter(prefix="/extract", tags=["rules"])


@router.post("/")
async def extract_rules(file: UploadFile = File(...)) -> dict[str, object]:
    """Extract data quality rules from a dataset.

    Upload a dataset file (CSV or JSON) and receive inferred rules in
    machine-readable form. The rule set is persisted and referenced by
    a unique identifier.

    Parameters
    ----------
    file : UploadFile
        The dataset file from which to extract rules.

    Returns
    -------
    dict[str, object]
        A dictionary containing the extracted rules and a rule set identifier.
    """
    try:
        contents = await file.read()
        name = file.filename or "dataset.csv"
        if name.endswith(".csv"):
            df = pd.read_csv(io.BytesIO(contents))
        elif name.endswith(".json"):
            df = pd.read_json(io.BytesIO(contents))
        else:
            df = pd.read_csv(io.BytesIO(contents))
    except Exception as exc:
        print(f"[EXTRACT] File parsing error: {exc}")
        traceback.print_exc()
        raise HTTPException(status_code=400, detail=f"Failed to parse file: {exc}") from exc

    try:
        # Generate a profile for basic statistics.
        profile = profile_dataframe(df)
        print(f"[EXTRACT] Profile generated")
        
        # Use LLM planner to select which extractors to use
        try:
            print(f"[EXTRACT] Initializing Phi3ExtractorPlanner...")
            planner = Phi3ExtractorPlanner()
            selected_extractors = planner.select_extractors(profile)
            print(f"[EXTRACT] LLM selected extractors: {selected_extractors}")
        except Exception as e:
            print(f"[EXTRACT] LLM planner failed, using default extractors: {e}")
            # Fallback to default extractors
            selected_extractors = [
                "extract_rules_from_profile",
                "find_categorical_rules",
                "find_regex_rules",
                "find_fd_rules",
            ]
        
        # Map extractor names to functions
        extractor_map = {
            "extract_rules_from_profile": lambda: extract_rules_from_profile(profile),
            "find_categorical_rules": lambda: find_categorical_rules(df),
            "find_regex_rules": lambda: find_regex_rules(df),
            "find_fd_rules": lambda: find_fd_rules(df),
            "find_outlier_rules": lambda: find_outlier_rules(df),
            "find_standardize_rules": lambda: find_standardize_rules(df),
            "find_inclusion_rules": lambda: find_inclusion_rules(df),
            "find_approx_fd_rules": lambda: find_approx_fd_rules(df),
            "find_conditional_fd_rules": lambda: find_conditional_fd_rules(df),
            "find_missing_pattern_rules": lambda: find_missing_pattern_rules(df),
            "find_domain_regex_rules": lambda: find_domain_regex_rules(df),
        }
        
        # Extract rules using selected extractors
        rules: list[dict[str, object]] = []
        for extractor_name in selected_extractors:
            if extractor_name in extractor_map:
                try:
                    extracted = extractor_map[extractor_name]()
                    rules.extend(extracted)
                    print(f"[EXTRACT] {extractor_name}: {len(extracted)} rules")
                except Exception as e:
                    print(f"[EXTRACT] {extractor_name} failed: {e}")
                    traceback.print_exc()
        
        # Add domain-specific finance rules if applicable
        try:
            finance_rules = extract_finance_rules(df)
            rules.extend(finance_rules)
            print(f"[EXTRACT] Finance rules: {len(finance_rules)} rules")
        except Exception as e:
            print(f"[EXTRACT] Finance rules failed: {e}")
        
        # Ensure each rule has a unique identifier and required fields
        for idx, rule in enumerate(rules, start=1):
            rule.setdefault("id", f"R{idx}")
            rule.setdefault("type", "unknown")
            rule.setdefault("column", "unknown")
        
        print(f"[EXTRACT] Total rules: {len(rules)}")
        
        # Rank rules by confidence score
        try:
            rules = rank_rules(rules, profile)
            print(f"[EXTRACT] Rules ranked")
        except Exception as e:
            print(f"[EXTRACT] Ranking failed: {e}")
        
        # Use LLM curator to refine and filter rules (with try-except)
        try:
            print(f"[EXTRACT] Curating rules with LLM...")
            curator = RuleCurator()
            rules = curator.curate(rules)
            print(f"[EXTRACT] Curation complete: {len(rules)} rules")
        except Exception as e:
            print(f"[EXTRACT] LLM curation failed, skipping: {e}")
            # Continue without curation
        
        # Detect and resolve conflicts
        try:
            conflicts = detect_conflicts(rules)
            if conflicts:
                rules = resolve_conflicts(rules, conflicts)
                print(f"[EXTRACT] Resolved {len(conflicts)} conflicts")
            else:
                conflicts = []
        except Exception as e:
            print(f"[EXTRACT] Conflict detection failed: {e}")
            conflicts = []
        
        # Filter low-confidence rules (threshold: 0.5)
        try:
            rules = filter_low_confidence_rules(rules, threshold=0.5)
            print(f"[EXTRACT] After filtering: {len(rules)} rules")
        except Exception as e:
            print(f"[EXTRACT] Filtering failed: {e}")
        
        # Save rules
        try:
            rule_set_id = save_rules(rules)
            print(f"[EXTRACT] Saved rule_set_id: {rule_set_id}")
        except Exception as e:
            print(f"[EXTRACT] Failed to save rules: {e}")
            raise HTTPException(status_code=500, detail=f"Failed to save rules: {e}")
        
        return {
            "rule_set_id": rule_set_id,
            "rules": rules,
            "conflicts": conflicts if conflicts else [],
            "selected_extractors": selected_extractors
        }
        
    except HTTPException:
        raise
    except Exception as exc:
        print(f"[EXTRACT] Fatal error: {exc}")
        traceback.print_exc()
        raise HTTPException(status_code=500, detail=f"Extract failed: {str(exc)}") from exc