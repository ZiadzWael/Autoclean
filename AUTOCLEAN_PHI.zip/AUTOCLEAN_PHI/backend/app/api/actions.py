"""Generic actions endpoints.

This module is reserved for future actions such as pre-defined cleaning
operations or user-defined functions. Currently it exposes a simple
placeholder endpoint.
"""

from fastapi import APIRouter

router = APIRouter(prefix="/actions", tags=["actions"])


@router.get("/ping")
async def ping() -> dict[str, str]:
    """Return a simple ping response.

    Useful for testing that the actions router is registered correctly.
    """
    return {"message": "pong"}