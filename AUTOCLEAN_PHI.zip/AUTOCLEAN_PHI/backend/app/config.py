"""Application configuration module.

Centralizes configuration constants such as data directories and model paths.
These settings may be adjusted via environment variables in a full
deployment, but are hard-coded here for clarity.
"""

from pathlib import Path
import os

# Base directory for the repository.
BASE_DIR = Path(__file__).resolve().parent.parent.parent

# Data directories for storage and vector database.
DATA_DIR = BASE_DIR / "data"
STORAGE_DIR = DATA_DIR / "storage"
CHROMA_DIR = DATA_DIR / "chroma_db"

# Directory to persist rule definitions.
RULES_DIR = DATA_DIR / "rules"

# Ensure data directories exist
DATA_DIR.mkdir(parents=True, exist_ok=True)
STORAGE_DIR.mkdir(parents=True, exist_ok=True)
CHROMA_DIR.mkdir(parents=True, exist_ok=True)
RULES_DIR.mkdir(parents=True, exist_ok=True)

print(f"[CONFIG] BASE_DIR: {BASE_DIR}")
print(f"[CONFIG] DATA_DIR: {DATA_DIR}")
print(f"[CONFIG] STORAGE_DIR: {STORAGE_DIR}")

# Model configuration for Phi-3 mini.
PHI3_MODEL_PATH = "X:/models/phi3-mini"

# Device used for inference; default to CPU when CUDA not available.
DEVICE = "cuda"

# Default generation hyperparameters.
MAX_NEW_TOKENS = 128
TEMPERATURE = 0.2