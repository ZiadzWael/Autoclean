"""Rule confidence scoring and ranking utilities."""

from __future__ import annotations

from typing import List, Dict, Any


def calculate_confidence_score(rule: Dict[str, Any], profile: Dict[str, Any] | None = None) -> float:
    """Calculate confidence score for a rule based on heuristics.

    Parameters
    ----------
    rule : dict[str, Any]
        The rule to score.
    profile : dict[str, Any], optional
        Dataset profile for context.

    Returns
    -------
    float
        Confidence score between 0.0 and 1.0.
    """
    rtype = rule.get("type")
    base_score = 0.7  # Default confidence
    
    # Adjust based on rule type
    if rtype == "not_null":
        # High confidence if no missing values observed
        if profile:
            col = rule.get("column")
            if col:
                col_stats = profile.get("columns", {}).get(col, {})
                missing_ratio = col_stats.get("missing_ratio", 1.0)
                if missing_ratio == 0.0:
                    base_score = 0.95
                else:
                    base_score = 0.5
        else:
            base_score = 0.8
    
    elif rtype == "unique":
        if profile:
            col = rule.get("column")
            if col:
                col_stats = profile.get("columns", {}).get(col, {})
                unique_count = col_stats.get("unique_count", 0)
                row_count = profile.get("row_count", 0)
                if row_count > 0 and unique_count == row_count:
                    base_score = 0.95
                else:
                    base_score = 0.6
        else:
            base_score = 0.75
    
    elif rtype == "range":
        min_val = rule.get("min")
        max_val = rule.get("max")
        if min_val is not None and max_val is not None:
            if min_val <= max_val:
                base_score = 0.85
            else:
                base_score = 0.1  # Invalid range
    
    elif rtype == "categorical":
        values = rule.get("values", [])
        if len(values) > 0 and len(values) <= 20:
            base_score = 0.8
        elif len(values) > 20:
            base_score = 0.5  # Too many categories
    
    elif rtype == "regex":
        pattern = rule.get("pattern")
        if pattern:
            base_score = 0.7
        else:
            base_score = 0.3
    
    elif rtype == "fd":
        base_score = 0.75  # Functional dependencies are usually reliable
    
    elif rtype == "outlier":
        mean = rule.get("mean")
        std = rule.get("std")
        if mean is not None and std is not None and std > 0:
            base_score = 0.7
        else:
            base_score = 0.3
    
    elif rtype == "standardize":
        base_score = 0.65  # Standardization is somewhat subjective
    
    elif rtype == "inclusion":
        base_score = 0.7
    
    # Adjust based on existing confidence score if present
    if "confidence_score" in rule:
        # Average with existing score
        base_score = (base_score + rule["confidence_score"]) / 2
    
    return min(1.0, max(0.0, base_score))


def rank_rules(rules: List[Dict[str, Any]], profile: Dict[str, Any] | None = None) -> List[Dict[str, Any]]:
    """Rank rules by confidence score.

    Parameters
    ----------
    rules : list[dict[str, Any]]
        Rules to rank.
    profile : dict[str, Any], optional
        Dataset profile for scoring.

    Returns
    -------
    list[dict[str, Any]]
        Rules sorted by confidence (highest first).
    """
    scored_rules = []
    for rule in rules:
        rule_copy = rule.copy()
        if "confidence_score" not in rule_copy:
            rule_copy["confidence_score"] = calculate_confidence_score(rule_copy, profile)
        scored_rules.append(rule_copy)
    
    # Sort by confidence score (highest first)
    scored_rules.sort(key=lambda x: x.get("confidence_score", 0.0), reverse=True)
    
    return scored_rules


def filter_low_confidence_rules(rules: List[Dict[str, Any]], threshold: float = 0.5) -> List[Dict[str, Any]]:
    """Filter out rules with confidence below threshold.

    Parameters
    ----------
    rules : list[dict[str, Any]]
        Rules to filter.
    threshold : float, default 0.5
        Minimum confidence score to keep.

    Returns
    -------
    list[dict[str, Any]]
        Filtered rules.
    """
    # Validate rules before filtering
    filtered = []
    for r in rules:
        # Skip rules missing required fields
        if not r.get("id") or not r.get("type") or not r.get("column"):
            continue
        # Keep rules above threshold
        if r.get("confidence_score", 0.0) >= threshold:
            filtered.append(r)
    return filtered
