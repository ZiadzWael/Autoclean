"""Top-level validation service.

Aggregates validation and suggestion generation to provide an end-to-end
assessment of data quality. This module coordinates the rule validator and
suggestion engine to return both violations and recommended repairs.
"""

from __future__ import annotations
from typing import List, Dict, Any
import pandas as pd

from .rule_validator import validate_dataframe
from .suggest import suggest_repairs


def assess_quality(df: pd.DataFrame, rules: List[Dict[str, Any]]) -> Dict[str, Any]:
    """Validate data and generate repair suggestions.

    Parameters
    ----------
    df : pd.DataFrame
        The DataFrame to assess.
    rules : list[dict[str, Any]]
        The rules to apply.

    Returns
    -------
    dict[str, Any]
        A dictionary containing both violations and suggestions.
    """
    violations = validate_dataframe(df, rules)
    suggestions = suggest_repairs(violations)
    return {"violations": violations, "suggestions": suggestions}