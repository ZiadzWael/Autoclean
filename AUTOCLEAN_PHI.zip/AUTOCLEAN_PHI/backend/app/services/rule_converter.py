"""Convert between internal rule representations and external formats.

In this simple implementation the converter is a pass-through. In the
future this module could support converting rules into SQL constraints or
other executable forms.
"""

from typing import List, Dict, Any


def to_external_format(rules: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """Return the rules unchanged."""
    return rules