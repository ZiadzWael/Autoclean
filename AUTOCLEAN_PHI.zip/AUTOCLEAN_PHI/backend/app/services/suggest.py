"""Suggestion generation for data repairs.

This module contains simple heuristics to suggest repairs based on rule
violations. In a production system this would invoke an LLM to propose
context-aware corrections.
"""

from __future__ import annotations
from typing import List, Dict, Any


def suggest_repairs(violations: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """Generate plain-text repair suggestions from violation records.

    Parameters
    ----------
    violations : list[dict[str, Any]]
        The violations produced by the validator.

    Returns
    -------
    list[dict[str, Any]]
        A list of suggestions with human-readable descriptions.
    """
    suggestions: list[dict[str, Any]] = []
    for violation in violations:
        col = violation["column"]
        rtype = violation["type"]
        count = violation["count"]
        if rtype == "not_null":
            description = (
                f"Column '{col}' has {count} missing values. "
                f"Consider filling missing entries with a default value."
            )
        elif rtype == "unique":
            description = (
                f"Column '{col}' has {count} duplicate values. "
                f"Consider removing duplicate rows or renaming values."
            )
        elif rtype == "range":
            description = (
                f"Column '{col}' has {count} out-of-range values. "
                f"Consider clipping values to the allowed range."
            )
        else:
            description = f"Violation on column '{col}' of type '{rtype}'."
        suggestions.append({"column": col, "rule": rtype, "suggestion": description})
    return suggestions