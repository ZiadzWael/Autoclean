"""Authentication and authorization utilities (stub).

In PH1, authentication is not implemented. This module contains placeholder
functions that always allow access.
"""


def verify_token(token: str) -> bool:
    """Always return True to allow access.

    Parameters
    ----------
    token : str
        The bearer token presented by the client.

    Returns
    -------
    bool
        Always True.
    """
    # In a real application this would verify the token signature and claims.
    return True