"""Persistence utilities for data quality rule sets.

Rule sets are stored as JSON files on disk. Each call to `save_rules`
generates a new UUID-based filename. The caller is responsible for
associating rule sets with datasets or other metadata.
"""

import json
import uuid
from pathlib import Path
from typing import List, Dict, Any

from ..config import RULES_DIR
from .rule_versioning import save_rule_version

# Ensure the rules directory exists.
Path(RULES_DIR).mkdir(parents=True, exist_ok=True)


def save_rules(rules: List[Dict[str, Any]], rule_set_id: str | None = None) -> str:
    """Persist a list of rule dictionaries to a JSON file with versioning.

    Parameters
    ----------
    rules : list[dict[str, Any]]
        The rule definitions to persist.
    rule_set_id : str, optional
        Existing rule set ID for versioning. If None, creates new rule set.

    Returns
    -------
    str
        The rule set identifier.
    """
    if rule_set_id is None:
        rule_set_id = uuid.uuid4().hex
    
    # Save current version
    path = Path(RULES_DIR) / f"{rule_set_id}.json"
    with path.open("w", encoding="utf-8") as f:
        json.dump(rules, f, ensure_ascii=False, indent=2)
    
    # Save version history
    save_rule_version(rule_set_id, rules)
    
    return rule_set_id


def load_rules(rule_set_id: str) -> List[Dict[str, Any]]:
    """Load a previously saved rule set by identifier.

    Parameters
    ----------
    rule_set_id : str
        The identifier returned by `save_rules`.

    Returns
    -------
    list[dict[str, Any]]
        The loaded rule definitions.

    Raises
    ------
    FileNotFoundError
        If the specified rule set file does not exist.
    """
    path = Path(RULES_DIR) / f"{rule_set_id}.json"
    with path.open("r", encoding="utf-8") as f:
        return json.load(f)


def update_rule(rule_set_id: str, rule_id: str, new_rule: Dict[str, Any]) -> List[Dict[str, Any]]:
    """Update a specific rule in a rule set.

    The rule set file is loaded, the specified rule is replaced with
    ``new_rule`` (matching on the ``id`` field), and the file is saved
    back to disk. If the rule is not found, a ``ValueError`` is raised.

    Parameters
    ----------
    rule_set_id : str
        Identifier of the rule set.
    rule_id : str
        Identifier of the rule to update.
    new_rule : dict[str, Any]
        Replacement rule dictionary. The ``id`` field of ``new_rule``
        should match ``rule_id``.

    Returns
    -------
    list[dict[str, Any]]
        The updated list of rules.
    """
    path = Path(RULES_DIR) / f"{rule_set_id}.json"
    if not path.exists():
        raise FileNotFoundError(f"Rule set {rule_set_id} not found")
    with path.open("r", encoding="utf-8") as f:
        rules = json.load(f)
    found = False
    updated_rules: List[Dict[str, Any]] = []
    for r in rules:
        if r.get("id") == rule_id:
            updated_rules.append(new_rule)
            found = True
        else:
            updated_rules.append(r)
    if not found:
        raise ValueError(f"Rule {rule_id} not found in rule set {rule_set_id}")
    # Persist the updated rules.
    with path.open("w", encoding="utf-8") as f:
        json.dump(updated_rules, f, ensure_ascii=False, indent=2)
    return updated_rules


def delete_rule(rule_set_id: str, rule_id: str) -> List[Dict[str, Any]]:
    """Delete a rule from a rule set by its identifier.

    Parameters
    ----------
    rule_set_id : str
        Identifier of the rule set.
    rule_id : str
        Identifier of the rule to delete.

    Returns
    -------
    list[dict[str, Any]]
        The remaining rules after deletion.
    """
    path = Path(RULES_DIR) / f"{rule_set_id}.json"
    if not path.exists():
        raise FileNotFoundError(f"Rule set {rule_set_id} not found")
    with path.open("r", encoding="utf-8") as f:
        rules = json.load(f)
    new_rules = [r for r in rules if r.get("id") != rule_id]
    if len(new_rules) == len(rules):
        raise ValueError(f"Rule {rule_id} not found in rule set {rule_set_id}")
    with path.open("w", encoding="utf-8") as f:
        json.dump(new_rules, f, ensure_ascii=False, indent=2)
    return new_rules