"""Heuristic rule extraction from dataset profiles.

This module contains logic to derive candidate data quality rules from simple
column statistics. Rules include constraints such as not-null requirements,
uniqueness constraints, and numeric ranges.
"""

from __future__ import annotations

from typing import List, Dict, Any
import re
import pandas as pd



def extract_rules_from_profile(profile: Dict[str, Any]) -> List[Dict[str, Any]]:
    """Generate data quality rules from a column profile.

    Rules are inferred based on heuristics:

    * Columns with zero missing values are marked as not-null.
    * Columns where every value is unique are marked as unique.
    * Numeric columns receive range constraints derived from the observed
      minimum and maximum.

    Parameters
    ----------
    profile : dict[str, Any]
        The profile dictionary produced by `profile_dataframe`.

    Returns
    -------
    list[dict[str, Any]]
        A list of rule dictionaries.
    """
    rules: list[dict[str, Any]] = []
    row_count = profile.get("row_count", 0)

    for col, stats in profile.get("columns", {}).items():
        missing_ratio = stats.get("missing_ratio", 0.0)
        unique_count = stats.get("unique_count", 0)

        # Infer not-null constraint if there are no missing values.
        if missing_ratio == 0.0:
            rules.append({"column": col, "type": "not_null"})

        # Infer uniqueness constraint if every value is unique (including missing).
        if row_count > 0 and unique_count == row_count:
            rules.append({"column": col, "type": "unique"})

        # Infer range constraint for numeric columns if min/max are present.
        if "min" in stats and "max" in stats:
            min_val = stats.get("min")
            max_val = stats.get("max")
            if min_val is not None and max_val is not None and min_val <= max_val:
                rules.append({"column": col, "type": "range", "min": min_val, "max": max_val})
    # Assign a stable identifier to each rule. These identifiers are useful for
    # tracking which rule was responsible for a particular repair when applying
    # rules to a dataset. The IDs are formatted as "R1", "R2", ... in the order
    # the rules were generated.
    for idx, rule in enumerate(rules, start=1):
        # Only set the id if it hasn't been set already. This allows callers to
        # preserve custom identifiers on rules if desired.
        rule.setdefault("id", f"R{idx}")

    return rules


#
# Additional rule discovery heuristics operating on the raw DataFrame.
# These functions are used to enrich the rule set with more complex
# constraints when the full dataset is available. They are designed to
# capture domain knowledge and structural patterns that cannot be inferred
# from simple column statistics alone.

def find_categorical_rules(df: pd.DataFrame, max_unique: int = 20) -> List[Dict[str, Any]]:
    """Identify categorical columns and enumerate their allowed values.

    A column is considered categorical if its number of unique values is
    below ``max_unique`` and the column's data type is object (string).

    Parameters
    ----------
    df : pd.DataFrame
        The DataFrame to analyze.
    max_unique : int, optional
        Maximum number of unique values for a column to be considered
        categorical. Defaults to 20.

    Returns
    -------
    list[dict[str, Any]]
        A list of categorical constraint rules.
    """
    rules: list[dict[str, Any]] = []
    for col in df.columns:
        if df[col].dtype == object:
            unique_vals = df[col].dropna().unique().tolist()
            if len(unique_vals) > 0 and len(unique_vals) <= max_unique:
                rules.append({
                    "column": col,
                    "type": "categorical",
                    "values": unique_vals
                })
    return rules


def find_regex_rules(df: pd.DataFrame) -> List[Dict[str, Any]]:
    """Infer simple regular expression patterns for string columns.

    This heuristic attempts to derive a coarse regex that captures the
    characters present in the majority of values within a column. Only
    columns of string type are considered. If the inferred pattern matches
    less than half of the non-null values, it is discarded.

    The generated pattern is of the form ``^[A-Za-z0-9-]+$`` or similar,
    depending on whether letters, digits, and/or hyphens are present. It
    does not attempt to detect complex formats (e.g., date strings).

    Parameters
    ----------
    df : pd.DataFrame
        The DataFrame to analyze.

    Returns
    -------
    list[dict[str, Any]]
        A list of regex constraint rules.
    """
    rules: list[dict[str, Any]] = []
    for col in df.columns:
        if df[col].dtype != object:
            continue
        # Sample non-null values to infer pattern.
        values = df[col].dropna().astype(str).tolist()
        if not values:
            continue
        # Flags indicating character classes observed.
        has_alpha = any(any(c.isalpha() for c in val) for val in values)
        has_digit = any(any(c.isdigit() for c in val) for val in values)
        has_hyphen = any('-' in val for val in values)
        # Build a simple character class based on observed characters.
        char_class_parts = []
        if has_alpha:
            char_class_parts.append('A-Za-z')
        if has_digit:
            char_class_parts.append('0-9')
        if has_hyphen:
            char_class_parts.append('\-')
        if not char_class_parts:
            continue
        pattern = f"^[{''.join(char_class_parts)}]+$"
        compiled = re.compile(pattern)
        match_count = sum(1 for val in values if compiled.match(val))
        if match_count >= len(values) / 2:
            rules.append({
                "column": col,
                "type": "regex",
                "pattern": pattern
            })
    return rules


def find_fd_rules(df: pd.DataFrame) -> List[Dict[str, Any]]:
    """Discover simple functional dependencies (FDs) in the DataFrame.

    A functional dependency ``A -> B`` exists if for every distinct value
    in column ``A``, there is exactly one corresponding value in column ``B``.
    This implementation checks all pairs of columns and identifies those
    relationships. Only exact dependencies are detected; approximate or
    conditional FDs are beyond the scope of this heuristic.

    Parameters
    ----------
    df : pd.DataFrame
        The DataFrame to analyze.

    Returns
    -------
    list[dict[str, Any]]
        A list of functional dependency rules.
    """
    rules: list[dict[str, Any]] = []
    cols = list(df.columns)
    for i, determinant in enumerate(cols):
        for j, dependent in enumerate(cols):
            if i == j:
                continue
            # Skip if either column has missing values; FDs assume complete data.
            if df[determinant].isna().any() or df[dependent].isna().any():
                continue
            # Build mapping from determinant values to dependent values.
            mapping = df.groupby(determinant)[dependent].nunique()
            if (mapping <= 1).all():
                rules.append({
                    "type": "fd",
                    "determinant": determinant,
                    "dependent": dependent
                })
    return rules


def find_outlier_rules(df: pd.DataFrame, z_thresh: float = 3.0) -> List[Dict[str, Any]]:
    """Detect potential outlier thresholds for numeric columns based on z-score.

    For each numeric column, compute the mean and standard deviation. A
    simple rule is generated indicating that values outside ``z_thresh``
    standard deviations from the mean are considered outliers. The rule
    does not specify how to repair outliers but can be used for validation
    or alerting.

    Parameters
    ----------
    df : pd.DataFrame
        The DataFrame to analyze.
    z_thresh : float, optional
        The z-score threshold for outlier detection. Defaults to 3.0.

    Returns
    -------
    list[dict[str, Any]]
        A list of outlier detection rules.
    """
    rules: list[dict[str, Any]] = []
    for col in df.columns:
        if pd.api.types.is_numeric_dtype(df[col]):
            series = df[col].dropna()
            if series.empty:
                continue
            mean = float(series.mean())
            std = float(series.std())
            if std == 0:
                continue
            rules.append({
                "column": col,
                "type": "outlier",
                "mean": mean,
                "std": std,
                "z_thresh": z_thresh
            })
    return rules


def find_standardize_rules(df: pd.DataFrame) -> List[Dict[str, Any]]:
    """Suggest standardization of string columns to a consistent case.

    If a string column contains a mix of uppercase and lowercase letters,
    generate a rule indicating the desired format (uppercase) based on the
    most common case observed. The rule can later be used by the apply
    engine to convert values accordingly.

    Parameters
    ----------
    df : pd.DataFrame
        The DataFrame to analyze.

    Returns
    -------
    list[dict[str, Any]]
        A list of standardization rules.
    """
    rules: list[dict[str, Any]] = []
    for col in df.columns:
        if df[col].dtype == object:
            values = df[col].dropna().astype(str)
            if values.empty:
                continue
            # Determine if there's a mixture of cases.
            has_upper = any(val != val.lower() for val in values)
            has_lower = any(val != val.upper() for val in values)
            if has_upper and has_lower:
                # Choose the most common case as the target format. Count uppercase letters across all values.
                upper_count = sum(sum(1 for ch in val if ch.isupper()) for val in values)
                lower_count = sum(sum(1 for ch in val if ch.islower()) for val in values)
                target = "uppercase" if upper_count >= lower_count else "lowercase"
                rules.append({
                    "column": col,
                    "type": "standardize",
                    "format": target
                })
    return rules


def find_inclusion_rules(df: pd.DataFrame) -> List[Dict[str, Any]]:
    """Find simple inclusion dependencies between columns.

    An inclusion dependency ``A ⊆ B`` exists if the set of non-null values
    in column ``A`` is a subset of the non-null values in column ``B``. Only
    string and integer columns are considered for inclusion dependencies.

    Parameters
    ----------
    df : pd.DataFrame
        The DataFrame to analyze.

    Returns
    -------
    list[dict[str, Any]]
        A list of inclusion dependency rules.
    """
    rules: list[dict[str, Any]] = []
    cols = list(df.columns)
    for i, a in enumerate(cols):
        for j, b in enumerate(cols):
            if i == j:
                continue
            # Work only with object or integer columns for inclusion.
            if not (df[a].dtype == object or pd.api.types.is_integer_dtype(df[a])):
                continue
            if not (df[b].dtype == object or pd.api.types.is_integer_dtype(df[b])):
                continue
            set_a = set(df[a].dropna().tolist())
            set_b = set(df[b].dropna().tolist())
            if set_a and set_a.issubset(set_b):
                rules.append({
                    "type": "inclusion",
                    "subset": a,
                    "superset": b
                })
    return rules


# ---------------------------------------------------------------------------
# Extended rule discovery heuristics
#
# The functions below implement more sophisticated rule extraction. These
# heuristics are not exhaustive but serve as a starting point for richer
# constraints. They may be particularly useful in domain‑specific contexts
# such as finance or ecommerce, where approximate relationships, conditional
# dependencies and patterned missingness are common. Each rule produced
# includes a unique identifier when combined with other rules during
# extraction.

def find_approx_fd_rules(df: pd.DataFrame, max_violations: float = 0.1) -> List[Dict[str, Any]]:
    """Identify approximate functional dependencies (FDs).

    A strict FD ``A -> B`` requires that each value of ``A`` maps to exactly one
    value of ``B``. In practice, datasets may contain occasional violations of
    this rule due to data entry errors or other noise. An approximate FD
    allows a small fraction of violations, specified by ``max_violations``.

    For each pair of columns, this function computes the proportion of
    determinant values that map to multiple dependent values. If the
    violation rate is less than or equal to ``max_violations``, a rule is
    generated. The rule records the tolerance to aid the apply engine.

    Parameters
    ----------
    df : pandas.DataFrame
        The DataFrame to analyze.
    max_violations : float, optional
        The maximum fraction of determinant values that may violate the
        dependency and still be considered approximately functional. Defaults
        to 0.1 (10% violations allowed).

    Returns
    -------
    list[dict[str, Any]]
        A list of approximate FD rules with keys ``determinant``,
        ``dependent`` and ``tolerance``.
    """
    rules: list[dict[str, Any]] = []
    cols = list(df.columns)
    nrows = len(df)
    if nrows == 0:
        return rules
    for i, determinant in enumerate(cols):
        for j, dependent in enumerate(cols):
            if i == j:
                continue
            # Skip pairs with missing values in either column; approximate FDs
            # cannot be assessed meaningfully with nulls present.
            if df[determinant].isna().any() or df[dependent].isna().any():
                continue
            # Compute the number of distinct dependent values for each
            # determinant value.
            mapping_counts = df.groupby(determinant)[dependent].nunique()
            # Count how many determinant values map to more than one dependent.
            violating = int((mapping_counts > 1).sum())
            total = len(mapping_counts)
            if total == 0:
                continue
            violation_rate = violating / total
            if violation_rate > 0 and violation_rate <= max_violations:
                rules.append({
                    "type": "approx_fd",
                    "determinant": determinant,
                    "dependent": dependent,
                    "tolerance": max_violations,
                    "violation_rate": violation_rate,
                })
    return rules


def find_conditional_fd_rules(df: pd.DataFrame, min_support: float = 0.7) -> List[Dict[str, Any]]:
    """Detect simple conditional functional dependencies (CFDs).

    A conditional FD ``A -> B | C`` states that within each subset of rows
    defined by a condition column ``C``, the value of ``B`` is determined by
    ``A``. This function searches for cases where a strict FD holds for
    most but not all distinct values of ``C``. If at least ``min_support``
    (e.g., 70%) of the condition values exhibit a strict dependency, the CFD
    is recorded. Only object and integer columns are considered for the
    condition to avoid a combinatorial explosion.

    Parameters
    ----------
    df : pandas.DataFrame
        The DataFrame to analyze.
    min_support : float, optional
        The minimum fraction of condition groups that must satisfy the FD
        relationship for the rule to be emitted. Defaults to 0.7.

    Returns
    -------
    list[dict[str, Any]]
        A list of CFD rules with keys ``determinant``, ``dependent``,
        ``condition`` and ``support``.
    """
    rules: list[dict[str, Any]] = []
    cols = list(df.columns)
    # Consider only small DataFrames to avoid combinatorial explosion.
    if len(cols) < 3 or len(df) == 0:
        return rules
    # Candidate condition columns should not be the same as determinant or
    # dependent; restrict to categorical columns for interpretability.
    candidate_conditions = [c for c in cols if df[c].dtype == object or pd.api.types.is_integer_dtype(df[c])]
    for det in cols:
        for dep in cols:
            if det == dep:
                continue
            if df[det].isna().any() or df[dep].isna().any():
                continue
            for cond in candidate_conditions:
                if cond in (det, dep):
                    continue
                groups = df.groupby(cond)
                total_groups = len(groups)
                if total_groups == 0:
                    continue
                satisfying = 0
                for _, subset in groups:
                    mapping = subset.groupby(det)[dep].nunique()
                    if (mapping <= 1).all():
                        satisfying += 1
                support = satisfying / total_groups
                if support >= min_support and satisfying > 0:
                    rules.append({
                        "type": "conditional_fd",
                        "determinant": det,
                        "dependent": dep,
                        "condition": cond,
                        "support": support,
                    })
    return rules


def find_missing_pattern_rules(df: pd.DataFrame, min_support: float = 0.8) -> List[Dict[str, Any]]:
    """Discover correlated missing value patterns between columns.

    When missing values in one column frequently coincide with missing values
    in another column, downstream processing can benefit from a rule that
    enforces this co‑missingness. For each pair of columns ``A`` and ``B``,
    this heuristic computes the conditional probability that ``B`` is
    missing given that ``A`` is missing. If this probability exceeds
    ``min_support`` and there are at least a handful of missing values in
    ``A``, a rule is generated.

    Parameters
    ----------
    df : pandas.DataFrame
        The DataFrame to analyze.
    min_support : float, optional
        The minimum conditional missingness required to emit a rule. Defaults
        to 0.8 (80%).

    Returns
    -------
    list[dict[str, Any]]
        A list of missing pattern rules with keys ``when_missing``,
        ``also_missing`` and ``support``.
    """
    rules: list[dict[str, Any]] = []
    cols = list(df.columns)
    nrows = len(df)
    if nrows == 0:
        return rules
    for i, a in enumerate(cols):
        for j, b in enumerate(cols):
            if i == j:
                continue
            # Determine rows where A is missing.
            mask_a = df[a].isna()
            total_missing_a = int(mask_a.sum())
            if total_missing_a == 0:
                continue
            # Among these rows, count how many have B missing.
            mask_b_given_a = df.loc[mask_a, b].isna()
            co_missing = int(mask_b_given_a.sum())
            support = co_missing / total_missing_a
            if support >= min_support and co_missing > 0:
                rules.append({
                    "type": "missing_pattern",
                    "when_missing": a,
                    "also_missing": b,
                    "support": support,
                })
    return rules


def find_domain_regex_rules(df: pd.DataFrame) -> List[Dict[str, Any]]:
    """Infer domain‑specific regular expressions for common string types.

    In addition to the generic character‑class regexes returned by
    ``find_regex_rules``, many domains rely on well‑known patterns. This
    function attempts to detect whether a column appears to contain
    email addresses, phone numbers, dates or credit card numbers. The
    heuristic inspects a sample of non‑null values for characteristic
    features (e.g., the presence of an "@" sign for email). If detected,
    a rule is emitted with the corresponding canonical regex.

    Supported domains and their patterns:

    * Email: ``^[^@\s]+@[^@\s]+\.[^@\s]+$``
    * Phone: ``^[0-9]{10,11}$`` (10–11 digits, no separators)
    * Date (ISO or slash): ``^(\d{4}-\d{2}-\d{2}|\d{2}/\d{2}/\d{4})$``
    * Credit card: ``^[0-9]{4}(?:[-\s]?[0-9]{4}){3}$``

    Parameters
    ----------
    df : pandas.DataFrame
        The DataFrame to analyze.

    Returns
    -------
    list[dict[str, Any]]
        A list of domain regex rules with keys ``column``, ``type``
        (always ``regex_domain``), ``domain`` and ``pattern``.
    """
    rules: list[dict[str, Any]] = []
    email_pattern = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")
    phone_pattern = re.compile(r"^\d{10,11}$")
    date_pattern = re.compile(r"^(\d{4}-\d{2}-\d{2}|\d{2}/\d{2}/\d{4})$")
    card_pattern = re.compile(r"^\d{4}(?:[-\s]?\d{4}){3}$")
    for col in df.columns:
        if df[col].dtype != object:
            continue
        sample_values = df[col].dropna().astype(str).head(100).tolist()
        if not sample_values:
            continue
        # Check for email pattern: requires '@' and '.' in sample values.
        if any('@' in val and '.' in val for val in sample_values):
            # If at least half of the sample matches the email pattern, emit rule.
            match_count = sum(1 for v in sample_values if email_pattern.match(v))
            if match_count >= len(sample_values) / 2:
                rules.append({
                    "column": col,
                    "type": "regex_domain",
                    "domain": "email",
                    "pattern": r"^[^@\s]+@[^@\s]+\.[^@\s]+$",
                })
                continue
        # Phone pattern: digits only 10 or 11 length.
        if any(phone_pattern.match(val) for val in sample_values):
            match_count = sum(1 for v in sample_values if phone_pattern.match(v))
            if match_count >= len(sample_values) / 2:
                rules.append({
                    "column": col,
                    "type": "regex_domain",
                    "domain": "phone",
                    "pattern": r"^[0-9]{10,11}$",
                })
                continue
        # Date pattern: ISO or DD/MM/YYYY.
        if any(date_pattern.match(val) for val in sample_values):
            match_count = sum(1 for v in sample_values if date_pattern.match(v))
            if match_count >= len(sample_values) / 2:
                rules.append({
                    "column": col,
                    "type": "regex_domain",
                    "domain": "date",
                    "pattern": r"^(\d{4}-\d{2}-\d{2}|\d{2}/\d{2}/\d{4})$",
                })
                continue
        # Credit card pattern: groups of 4 digits separated by hyphen or space.
        if any(card_pattern.match(val.replace(" ", "").replace("-", "")) for val in sample_values):
            # To evaluate, normalise sample by removing separators.
            match_count = sum(1 for v in sample_values if card_pattern.match(v))
            if match_count >= len(sample_values) / 2:
                rules.append({
                    "column": col,
                    "type": "regex_domain",
                    "domain": "credit_card",
                    "pattern": r"^[0-9]{4}(?:[-\s]?[0-9]{4}){3}$",
                })
                continue
    return rules