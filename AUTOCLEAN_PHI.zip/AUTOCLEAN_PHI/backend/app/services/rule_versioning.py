"""Rule versioning and history tracking."""

from __future__ import annotations

from typing import List, Dict, Any, Optional
from datetime import datetime
import json
from pathlib import Path

from ..config import RULES_DIR


def save_rule_version(rule_set_id: str, rules: List[Dict[str, Any]], version: Optional[int] = None) -> int:
    """Save a version of rules with history tracking.

    Parameters
    ----------
    rule_set_id : str
        Rule set identifier.
    rules : list[dict[str, Any]]
        Rules to save.
    version : int, optional
        Specific version number. If None, auto-increments.

    Returns
    -------
    int
        Version number.
    """
    RULES_DIR.mkdir(parents=True, exist_ok=True)
    
    # Load existing versions to determine next version
    history_file = RULES_DIR / f"{rule_set_id}_history.json"
    if history_file.exists():
        with history_file.open("r") as f:
            history = json.load(f)
        versions = history.get("versions", [])
        next_version = version if version is not None else (max([v["version"] for v in versions], default=0) + 1)
    else:
        next_version = version if version is not None else 1
        history = {"rule_set_id": rule_set_id, "versions": []}
    
    # Save version
    version_data = {
        "version": next_version,
        "timestamp": datetime.utcnow().isoformat(),
        "rule_count": len(rules),
        "rules": rules
    }
    
    history["versions"].append(version_data)
    history["latest_version"] = next_version
    
    # Keep only last 50 versions
    if len(history["versions"]) > 50:
        history["versions"] = history["versions"][-50:]
    
    with history_file.open("w") as f:
        json.dump(history, f, indent=2)
    
    return next_version


def get_rule_version(rule_set_id: str, version: int) -> Optional[List[Dict[str, Any]]]:
    """Retrieve a specific version of rules.

    Parameters
    ----------
    rule_set_id : str
        Rule set identifier.
    version : int
        Version number.

    Returns
    -------
    list[dict[str, Any]] | None
        Rules for the specified version, or None if not found.
    """
    history_file = RULES_DIR / f"{rule_set_id}_history.json"
    if not history_file.exists():
        return None
    
    with history_file.open("r") as f:
        history = json.load(f)
    
    for v_data in history.get("versions", []):
        if v_data["version"] == version:
            return v_data["rules"]
    
    return None


def get_rule_history(rule_set_id: str) -> List[Dict[str, Any]]:
    """Get version history for a rule set.

    Parameters
    ----------
    rule_set_id : str
        Rule set identifier.

    Returns
    -------
    list[dict[str, Any]]
        List of version metadata.
    """
    history_file = RULES_DIR / f"{rule_set_id}_history.json"
    if not history_file.exists():
        return []
    
    with history_file.open("r") as f:
        history = json.load(f)
    
    return [
        {
            "version": v["version"],
            "timestamp": v["timestamp"],
            "rule_count": v["rule_count"]
        }
        for v in history.get("versions", [])
    ]


def compare_rule_versions(rule_set_id: str, version1: int, version2: int) -> Dict[str, Any]:
    """Compare two versions of rules.

    Parameters
    ----------
    rule_set_id : str
        Rule set identifier.
    version1 : int
        First version number.
    version2 : int
        Second version number.

    Returns
    -------
    dict[str, Any]
        Comparison results.
    """
    rules1 = get_rule_version(rule_set_id, version1) or []
    rules2 = get_rule_version(rule_set_id, version2) or []
    
    rule_ids1 = {r.get("id") for r in rules1}
    rule_ids2 = {r.get("id") for r in rules2}
    
    added = [r for r in rules2 if r.get("id") not in rule_ids1]
    removed = [r for r in rules1 if r.get("id") not in rule_ids2]
    modified = []
    
    for r2 in rules2:
        r1 = next((r for r in rules1 if r.get("id") == r2.get("id")), None)
        if r1 and r1 != r2:
            modified.append({"rule_id": r2.get("id"), "old": r1, "new": r2})
    
    return {
        "version1": version1,
        "version2": version2,
        "added": added,
        "removed": removed,
        "modified": modified,
        "unchanged": len(rules1) - len(removed) - len(modified)
    }
