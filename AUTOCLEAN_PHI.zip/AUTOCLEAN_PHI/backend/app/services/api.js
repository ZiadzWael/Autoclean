const API_BASE = 'http://127.0.0.1:8001'

export const api = {
  async uploadFile(file) {
    const formData = new FormData()
    formData.append('file', file)
    
    const res = await fetch(`${API_BASE}/ingest/`, {
      method: 'POST',
      body: formData,
    })
    
    if (!res.ok) throw new Error(`Upload failed: ${res.status}`)
    return await res.json()
  },
  
  async extractRules(file) {
    const formData = new FormData()
    formData.append('file', file)
    
    const res = await fetch(`${API_BASE}/extract/`, {
      method: 'POST',
      body: formData,
    })
    
    return await res.json()
  },
  
  async validateDataset(file, ruleSetId) {
    const formData = new FormData()
    formData.append('file', file)
    formData.append('rule_set_id', ruleSetId)
    
    const res = await fetch(`${API_BASE}/validate/`, {
      method: 'POST',
      body: formData,
    })
    
    if (!res.ok) throw new Error(`Validation failed: ${res.status}`)
    return await res.json()
  },
  
  async applyRules(file, ruleSetId, ruleIds = []) {
    const formData = new FormData()
    formData.append('file', file)
    formData.append('rule_set_id', ruleSetId)
    
    if (ruleIds.length > 0) {
      formData.append('rule_ids', ruleIds.join(','))
    }
    
    const res = await fetch(`${API_BASE}/apply/`, {
      method: 'POST',
      body: formData,
    })
    
    return await res.json()
  },
  
  async deleteRule(ruleSetId, ruleId) {
    const res = await fetch(`${API_BASE}/rules/${ruleSetId}/${ruleId}`, {
      method: 'DELETE',
    })
    
    if (!res.ok) throw new Error(`Delete failed: ${res.status}`)
    return await res.json()
  }
}