"""Column mapping utilities (stub).

The column mapper resolves dataset column names to canonical names. This is
a stub implementation that returns the identity mapping.
"""

from typing import Dict


def map_columns(columns: Dict[str, str]) -> Dict[str, str]:
    """Return the provided mapping unchanged."""
    return columns