"""Domain-specific finance rules."""

from __future__ import annotations

from typing import List, Dict, Any
import re
import pandas as pd


def extract_finance_rules(df: pd.DataFrame) -> List[Dict[str, Any]]:
    """Extract finance-specific data quality rules.

    Parameters
    ----------
    df : pd.DataFrame
        The DataFrame to analyze.

    Returns
    -------
    list[dict[str, Any]]
        List of finance-specific rules.
    """
    rules: list[dict[str, Any]] = []
    
    # Currency code validation (ISO 4217)
    currency_pattern = r'^[A-Z]{3}$'
    for col in df.columns:
        if 'currency' in col.lower() or 'curr' in col.lower():
            sample_values = df[col].dropna().astype(str).head(10).tolist()
            if sample_values and all(re.match(currency_pattern, v.strip()) for v in sample_values if v):
                rules.append({
                    "column": col,
                    "type": "regex",
                    "pattern": currency_pattern,
                    "domain": "finance",
                    "description": "Currency code must be ISO 4217 format (3 uppercase letters)"
                })
    
    # Account number format (typically numeric or alphanumeric)
    for col in df.columns:
        if 'account' in col.lower() and 'number' in col.lower():
            sample_values = df[col].dropna().astype(str).head(10).tolist()
            if sample_values:
                # Check if mostly numeric/alphanumeric
                if all(v.replace('-', '').replace(' ', '').isalnum() for v in sample_values if v):
                    rules.append({
                        "column": col,
                        "type": "regex",
                        "pattern": r'^[A-Za-z0-9\s\-]+$',
                        "domain": "finance",
                        "description": "Account number must be alphanumeric"
                    })
    
    # Transaction amount validation (non-negative)
    for col in df.columns:
        if 'amount' in col.lower() or 'balance' in col.lower():
            if pd.api.types.is_numeric_dtype(df[col]):
                negative_count = (df[col] < 0).sum()
                if negative_count == 0:
                    rules.append({
                        "column": col,
                        "type": "range",
                        "min": 0,
                        "domain": "finance",
                        "description": "Financial amounts must be non-negative"
                    })
    
    # Date consistency: transaction date should be <= current date
    for col in df.columns:
        if 'date' in col.lower() and 'transaction' in col.lower():
            if pd.api.types.is_datetime64_any_dtype(df[col]) or df[col].dtype == object:
                try:
                    dates = pd.to_datetime(df[col], errors='coerce')
                    if dates.notna().any():
                        rules.append({
                            "column": col,
                            "type": "range",
                            "max": pd.Timestamp.now().isoformat(),
                            "domain": "finance",
                            "description": "Transaction date cannot be in the future"
                        })
                except Exception:
                    pass
    
    # Transaction type validation (common finance transaction types)
    transaction_types = ['debit', 'credit', 'transfer', 'withdrawal', 'deposit', 'payment']
    for col in df.columns:
        if 'type' in col.lower() and 'transaction' in col.lower():
            unique_vals = df[col].dropna().astype(str).str.lower().unique()
            if len(unique_vals) <= 20:
                # Check if values match common transaction types
                matching = [v for v in unique_vals if any(tt in v for tt in transaction_types)]
                if len(matching) > len(unique_vals) * 0.5:
                    rules.append({
                        "column": col,
                        "type": "categorical",
                        "values": list(unique_vals),
                        "domain": "finance",
                        "description": "Transaction type must be a valid finance transaction type"
                    })
    
    # IBAN format validation (if detected)
    iban_pattern = r'^[A-Z]{2}[0-9]{2}[A-Z0-9]+$'
    for col in df.columns:
        if 'iban' in col.lower():
            sample_values = df[col].dropna().astype(str).head(5).tolist()
            if sample_values and all(re.match(iban_pattern, v.replace(' ', '')) for v in sample_values if len(v) >= 15):
                rules.append({
                    "column": col,
                    "type": "regex",
                    "pattern": iban_pattern,
                    "domain": "finance",
                    "description": "IBAN must follow international format"
                })
    
    return rules
