"""Rule conflict detection and resolution."""

from __future__ import annotations

from typing import List, Dict, Any


def detect_conflicts(rules: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """Detect conflicts between rules.

    Parameters
    ----------
    rules : list[dict[str, Any]]
        List of rules to check for conflicts.

    Returns
    -------
    list[dict[str, Any]]
        List of conflict records with rule IDs and conflict type.
    """
    conflicts: list[dict[str, Any]] = []
    
    # Group rules by column
    column_rules: dict[str, list[dict[str, Any]]] = {}
    for rule in rules:
        col = rule.get("column")
        if col:
            if col not in column_rules:
                column_rules[col] = []
            column_rules[col].append(rule)
    
    # Check for conflicts
    for col, col_rules in column_rules.items():
        rule_types = {r.get("type") for r in col_rules}
        rule_ids = [r.get("id") for r in col_rules]
        
        # Conflict: unique + categorical (categorical implies duplicates are allowed)
        if "unique" in rule_types and "categorical" in rule_types:
            conflicts.append({
                "type": "unique_categorical_conflict",
                "column": col,
                "rule_ids": rule_ids,
                "message": f"Column '{col}' has both unique and categorical constraints - categorical allows duplicates"
            })
        
        # Conflict: range with min > max
        range_rules = [r for r in col_rules if r.get("type") == "range"]
        for rule in range_rules:
            min_val = rule.get("min")
            max_val = rule.get("max")
            if min_val is not None and max_val is not None and min_val > max_val:
                conflicts.append({
                    "type": "invalid_range",
                    "column": col,
                    "rule_ids": [rule.get("id")],
                    "message": f"Range rule for '{col}' has min ({min_val}) > max ({max_val})"
                })
        
        # Conflict: standardize with categorical (standardization might change categorical values)
        if "standardize" in rule_types and "categorical" in rule_types:
            conflicts.append({
                "type": "standardize_categorical_conflict",
                "column": col,
                "rule_ids": rule_ids,
                "message": f"Column '{col}' has both standardization and categorical constraints - standardization may change categorical values"
            })
    
    # Check FD conflicts: circular dependencies
    fd_rules = [r for r in rules if r.get("type") == "fd"]
    fd_pairs = {(r.get("determinant"), r.get("dependent")) for r in fd_rules}
    for det, dep in fd_pairs:
        if (dep, det) in fd_pairs:
            conflicts.append({
                "type": "circular_fd",
                "rule_ids": [
                    r.get("id") for r in fd_rules 
                    if (r.get("determinant"), r.get("dependent")) == (det, dep) or
                       (r.get("determinant"), r.get("dependent")) == (dep, det)
                ],
                "message": f"Circular functional dependency detected: {det} ↔ {dep}"
            })
    
    return conflicts


def resolve_conflicts(rules: List[Dict[str, Any]], conflicts: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """Resolve conflicts by removing or modifying conflicting rules.

    Parameters
    ----------
    rules : list[dict[str, Any]]
        Original rules.
    conflicts : list[dict[str, Any]]
        Detected conflicts.

    Returns
    -------
    list[dict[str, Any]]
        Resolved rules (conflicting rules removed or modified).
    """
    resolved = rules.copy()
    conflict_rule_ids = set()
    
    for conflict in conflicts:
        rule_ids = conflict.get("rule_ids", [])
        conflict_type = conflict.get("type")
        
        if conflict_type == "unique_categorical_conflict":
            # Keep categorical, remove unique (categorical is more specific)
            conflict_rule_ids.update([rid for rid in rule_ids if any(
                r.get("id") == rid and r.get("type") == "unique" for r in resolved
            )])
        elif conflict_type == "standardize_categorical_conflict":
            # Keep categorical, remove standardize
            conflict_rule_ids.update([rid for rid in rule_ids if any(
                r.get("id") == rid and r.get("type") == "standardize" for r in resolved
            )])
        elif conflict_type == "invalid_range":
            # Remove invalid range rules
            conflict_rule_ids.update(rule_ids)
        elif conflict_type == "circular_fd":
            # Keep the first FD, remove the reverse
            conflict_rule_ids.update(rule_ids[1:] if len(rule_ids) > 1 else rule_ids)
    
    # Remove conflicting rules
    resolved = [r for r in resolved if r.get("id") not in conflict_rule_ids]
    
    return resolved
