"""Performance metrics and analytics for rule effectiveness."""

from __future__ import annotations

from typing import List, Dict, Any, Optional
import pandas as pd
from datetime import datetime
import json
from pathlib import Path

from ..config import DATA_DIR


_METRICS_FILE = DATA_DIR / "metrics.json"


def calculate_rule_effectiveness(
    original_df: pd.DataFrame,
    cleaned_df: pd.DataFrame,
    rules: List[Dict[str, Any]],
    modifications: List[Dict[str, Any]]
) -> Dict[str, Any]:
    """Calculate effectiveness metrics for applied rules.

    Parameters
    ----------
    original_df : pd.DataFrame
        Original dataset.
    cleaned_df : pd.DataFrame
        Cleaned dataset.
    rules : list[dict[str, Any]]
        Applied rules.
    modifications : list[dict[str, Any]]
        Modification log.

    Returns
    -------
    dict[str, Any]
        Effectiveness metrics.
    """
    total_rows = len(original_df)
    total_cells = total_rows * len(original_df.columns)
    
    # Count modifications by rule
    modifications_by_rule = {}
    for mod in modifications:
        rule_id = mod.get("rule_id", "unknown")
        if rule_id not in modifications_by_rule:
            modifications_by_rule[rule_id] = 0
        modifications_by_rule[rule_id] += 1
    
    total_modifications = len(modifications)
    modification_rate = total_modifications / total_cells if total_cells > 0 else 0
    
    # Calculate data quality improvement
    original_quality = _calculate_data_quality_score(original_df)
    cleaned_quality = _calculate_data_quality_score(cleaned_df)
    quality_improvement = cleaned_quality - original_quality
    
    # Rule coverage (how many rules actually made changes)
    active_rules = len(modifications_by_rule)
    rule_coverage = active_rules / len(rules) if rules else 0
    
    metrics = {
        "timestamp": datetime.utcnow().isoformat(),
        "total_rows": total_rows,
        "total_cells": total_cells,
        "total_modifications": total_modifications,
        "modification_rate": modification_rate,
        "original_quality_score": original_quality,
        "cleaned_quality_score": cleaned_quality,
        "quality_improvement": quality_improvement,
        "active_rules": active_rules,
        "total_rules": len(rules),
        "rule_coverage": rule_coverage,
        "modifications_by_rule": modifications_by_rule
    }
    
    # Save metrics
    _save_metrics(metrics)
    
    return metrics


def _calculate_data_quality_score(df: pd.DataFrame) -> float:
    """Calculate a simple data quality score (0-1)."""
    if df.empty:
        return 0.0
    
    total_cells = len(df) * len(df.columns)
    if total_cells == 0:
        return 0.0
    
    # Penalize missing values
    missing_count = df.isna().sum().sum()
    completeness = 1.0 - (missing_count / total_cells)
    
    # Penalize duplicates
    duplicate_rows = df.duplicated().sum()
    uniqueness = 1.0 - (duplicate_rows / len(df)) if len(df) > 0 else 1.0
    
    # Average of completeness and uniqueness
    quality_score = (completeness + uniqueness) / 2.0
    
    return max(0.0, min(1.0, quality_score))


def calculate_precision_recall(
    violations_before: List[Dict[str, Any]],
    violations_after: List[Dict[str, Any]],
    modifications: List[Dict[str, Any]]
) -> Dict[str, float]:
    """Calculate precision and recall for rule application.

    Parameters
    ----------
    violations_before : list[dict[str, Any]]
        Violations before cleaning.
    violations_after : list[dict[str, Any]]
        Violations after cleaning.
    modifications : list[dict[str, Any]]
        Modifications made.

    Returns
    -------
    dict[str, float]
        Precision and recall metrics.
    """
    total_violations_before = sum(v.get("count", 0) for v in violations_before)
    total_violations_after = sum(v.get("count", 0) for v in violations_after)
    violations_fixed = total_violations_before - total_violations_after
    
    # Precision: of all modifications, how many fixed actual violations?
    # (Simplified - assumes modifications target violations)
    precision = violations_fixed / len(modifications) if modifications else 0.0
    
    # Recall: of all violations, how many were fixed?
    recall = violations_fixed / total_violations_before if total_violations_before > 0 else 0.0
    
    # F1 score
    f1 = 2 * (precision * recall) / (precision + recall) if (precision + recall) > 0 else 0.0
    
    return {
        "precision": precision,
        "recall": recall,
        "f1_score": f1,
        "violations_before": total_violations_before,
        "violations_after": total_violations_after,
        "violations_fixed": violations_fixed
    }


def _save_metrics(metrics: Dict[str, Any]) -> None:
    """Save metrics to file."""
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    
    if _METRICS_FILE.exists():
        with _METRICS_FILE.open("r") as f:
            all_metrics = json.load(f)
    else:
        all_metrics = {"metrics": []}
    
    all_metrics["metrics"].append(metrics)
    
    # Keep only last 1000 metrics
    if len(all_metrics["metrics"]) > 1000:
        all_metrics["metrics"] = all_metrics["metrics"][-1000:]
    
    with _METRICS_FILE.open("w") as f:
        json.dump(all_metrics, f, indent=2)


def get_metrics_history(limit: int = 100) -> List[Dict[str, Any]]:
    """Get historical metrics.

    Parameters
    ----------
    limit : int, default 100
        Maximum number of metrics to return.

    Returns
    -------
    list[dict[str, Any]]
        Historical metrics.
    """
    if not _METRICS_FILE.exists():
        return []
    
    with _METRICS_FILE.open("r") as f:
        all_metrics = json.load(f)
    
    return all_metrics.get("metrics", [])[-limit:]


def calculate_cost_benefit(
    modifications: List[Dict[str, Any]],
    time_taken: float,
    quality_improvement: float
) -> Dict[str, Any]:
    """Calculate cost-benefit analysis of cleaning.

    Parameters
    ----------
    modifications : list[dict[str, Any]]
        Modifications made.
    time_taken : float
        Time taken in seconds.
    quality_improvement : float
        Quality improvement score.

    Returns
    -------
    dict[str, Any]
        Cost-benefit metrics.
    """
    total_modifications = len(modifications)
    modifications_per_second = total_modifications / time_taken if time_taken > 0 else 0
    
    # Simple cost-benefit: quality improvement per modification
    benefit_per_modification = quality_improvement / total_modifications if total_modifications > 0 else 0
    
    return {
        "total_modifications": total_modifications,
        "time_taken_seconds": time_taken,
        "modifications_per_second": modifications_per_second,
        "quality_improvement": quality_improvement,
        "benefit_per_modification": benefit_per_modification,
        "efficiency_score": quality_improvement / time_taken if time_taken > 0 else 0
    }
