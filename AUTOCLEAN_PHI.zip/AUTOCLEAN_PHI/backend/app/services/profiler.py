"""Dataset profiling utilities.

The profiler scans pandas DataFrames and computes simple descriptive
statistics per column. These statistics are used downstream to infer
candidate data quality rules.
"""

from __future__ import annotations

import pandas as pd


def profile_dataframe(df: pd.DataFrame) -> dict[str, object]:
    """Compute a profile for each column in a DataFrame.

    The profile includes the data type, missing value ratio, unique value
    count, and, for numeric columns, the minimum and maximum values.

    Parameters
    ----------
    df : pd.DataFrame
        The DataFrame to profile.

    Returns
    -------
    dict[str, object]
        A dictionary containing a row count and per-column statistics.
    """
    profile: dict[str, object] = {"row_count": int(len(df)), "columns": {}}

    for col in df.columns:
        series = df[col]
        stats: dict[str, object] = {
            "dtype": str(series.dtype),
            "missing_ratio": float(series.isna().mean()),
            "unique_count": int(series.nunique(dropna=True)),
        }

        # Include range statistics for numeric columns.
        if pd.api.types.is_numeric_dtype(series):
            try:
                stats["min"] = float(series.min(skipna=True))
                stats["max"] = float(series.max(skipna=True))
            except Exception:
                # In case conversion fails, skip range stats.
                pass

        profile["columns"][col] = stats

    return profile