"""ChromaDB-based indexer for retrieval-augmented generation."""

from __future__ import annotations

from typing import List, Dict, Any
import chromadb
from chromadb.config import Settings

from ...config import CHROMA_DIR


class InMemoryIndexer:
    """ChromaDB-based indexer for semantic search."""

    def __init__(self, collection_name: str = "rules") -> None:
        """Initialize ChromaDB client and collection."""
        CHROMA_DIR.mkdir(parents=True, exist_ok=True)
        self.client = chromadb.PersistentClient(
            path=str(CHROMA_DIR),
            settings=Settings(anonymized_telemetry=False)
        )
        self.collection = self.client.get_or_create_collection(
            name=collection_name,
            metadata={"description": "Rule examples and domain knowledge"}
        )

    def add_document(self, content: str, metadata: Dict[str, Any] | None = None) -> None:
        """Add a document to the index."""
        metadata = metadata or {}
        # Use content as both id and document
        doc_id = metadata.get("id", f"doc_{len(self.collection.get()['ids'])}")
        self.collection.add(
            documents=[content],
            ids=[doc_id],
            metadatas=[metadata]
        )

    def search(self, query: str, top_k: int = 5) -> List[Dict[str, Any]]:
        """Search for similar documents using semantic similarity."""
        results = self.collection.query(
            query_texts=[query],
            n_results=top_k
        )
        
        documents = []
        if results["documents"] and len(results["documents"]) > 0:
            for i in range(len(results["documents"][0])):
                documents.append({
                    "content": results["documents"][0][i],
                    "metadata": results["metadatas"][0][i] if results["metadatas"] else {},
                    "distance": results["distances"][0][i] if results["distances"] else None
                })
        return documents
