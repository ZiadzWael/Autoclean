"""Retriever interface for ChromaDB-based RAG."""

from __future__ import annotations
from typing import List, Dict, Any
import json

from .indexer import InMemoryIndexer


class Retriever:
    """Retriever that wraps the ChromaDB indexer."""

    def __init__(self, indexer: InMemoryIndexer | None = None) -> None:
        """Initialize retriever with indexer."""
        self.indexer = indexer or InMemoryIndexer()

    def retrieve(self, query: str, top_k: int = 5) -> List[Dict[str, Any]]:
        """Retrieve relevant documents for a query using semantic search."""
        return self.indexer.search(query, top_k)
    
    def add_rule_example(self, rule: Dict[str, Any], context: str = "") -> None:
        """Add a rule example to the RAG index."""
        content = f"Rule type: {rule.get('type')}\nColumn: {rule.get('column', 'N/A')}\n{json.dumps(rule, indent=2)}\nContext: {context}"
        metadata = {
            "type": "rule_example",
            "rule_type": rule.get("type"),
            "column": rule.get("column", ""),
            "id": rule.get("id", "")
        }
        self.indexer.add_document(content, metadata)
    
    def add_domain_knowledge(self, knowledge: str, domain: str = "general") -> None:
        """Add domain-specific knowledge to the RAG index."""
        metadata = {"type": "domain_knowledge", "domain": domain}
        self.indexer.add_document(knowledge, metadata)