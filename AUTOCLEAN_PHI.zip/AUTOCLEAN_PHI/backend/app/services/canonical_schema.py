"""Utility functions for dealing with canonical data schemas (stub).

The canonical schema defines expected column names and types for different
domains. In PH1 this module returns trivial pass-through mappings.
"""

from typing import Dict


def get_canonical_schema(name: str) -> Dict[str, str]:
    """Return a trivial canonical schema for the given name."""
    # In a real implementation, this would lookup a schema definition.
    return {}