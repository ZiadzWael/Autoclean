"""Engine for applying data quality rules to a dataset.

The apply engine produces a cleaned DataFrame by enforcing the provided
rules. Missing values are imputed based on column type, duplicates are
removed for unique constraints, and numeric values are clipped to the
observed range.
"""

from __future__ import annotations
from typing import List, Dict, Any
from collections import Counter
import re
import pandas as pd


def apply_rules_to_dataframe(
    df: pd.DataFrame, rules: List[Dict[str, Any]]
) -> tuple[pd.DataFrame, List[Dict[str, Any]]]:
    """Apply rules to a DataFrame and return a cleaned copy along with
    detailed modification logs.

    Each rule may perform one or more repairs on the dataset. As the rules
    are applied, any changes to cell values or row drops are recorded in a
    list of modification dictionaries. Each modification captures the rule
    identifier, the type of rule, the affected column, and the original
    and new values. For duplicate removal, a modification entry is
    generated for each dropped row with the new value set to ``None``.

    Parameters
    ----------
    df : pd.DataFrame
        The DataFrame to clean.
    rules : list[dict[str, Any]]
        The rules to apply. Each rule should include an ``id`` field to
        uniquely identify it.

    Returns
    -------
    tuple[pd.DataFrame, list[dict[str, Any]]]
        A tuple containing the cleaned DataFrame and a list of
        modification dictionaries.
    """
    cleaned = df.copy()
    modifications: list[dict[str, Any]] = []

    # Iterate over the rules in the order provided. For each rule, apply
    # the corresponding transformation and record any changes made.
    for rule in rules:
        col = rule.get("column")
        rtype = rule.get("type")
        rule_id = rule.get("id") or ""
        if col not in cleaned.columns:
            continue

        # Handle missing value imputation for not-null constraints.
        if rtype == "not_null":
            # Identify rows with missing values before imputation.
            missing_mask = cleaned[col].isna()
            if missing_mask.any():
                if pd.api.types.is_numeric_dtype(cleaned[col]):
                    replacement = cleaned[col].median(skipna=True)
                else:
                    # Use the mode (most frequent) value; if no mode exists, fallback to empty string.
                    mode_series = cleaned[col].mode(dropna=True)
                    replacement = mode_series.iloc[0] if not mode_series.empty else ""

                # Apply the replacement and record each change.
                for idx in cleaned[missing_mask].index:
                    old_val = cleaned.loc[idx, col]
                    cleaned.at[idx, col] = replacement
                    modifications.append({
                        "rule_id": rule_id,
                        "rule_type": rtype,
                        "action": "impute_missing",
                        "column": col,
                        "row_index": int(idx),
                        "old_value": old_val if pd.notna(old_val) else None,
                        "new_value": replacement,
                    })

        # Handle uniqueness constraints by removing duplicates.
        elif rtype == "unique":
            # Find duplicate indices (excluding the first occurrence).
            duplicate_indices = cleaned[cleaned.duplicated(subset=[col], keep='first')].index.tolist()
            for idx in duplicate_indices:
                old_val = cleaned.loc[idx, col]
                modifications.append({
                    "rule_id": rule_id,
                    "rule_type": rtype,
                    "action": "drop_duplicate",
                    "column": col,
                    "row_index": int(idx),
                    "old_value": old_val,
                    "new_value": None,
                })
            # Drop duplicates from the DataFrame.
            cleaned = cleaned.drop_duplicates(subset=[col])

        # Handle range constraints by clamping values outside the range.
        elif rtype == "range":
            min_val = rule.get("min")
            max_val = rule.get("max")
            if min_val is not None:
                below_mask = cleaned[col] < min_val
                for idx in cleaned[below_mask].index:
                    old_val = cleaned.loc[idx, col]
                    cleaned.at[idx, col] = min_val
                    modifications.append({
                        "rule_id": rule_id,
                        "rule_type": rtype,
                        "action": "clamp_range",
                        "column": col,
                        "row_index": int(idx),
                        "old_value": old_val,
                        "new_value": min_val,
                    })
            if max_val is not None:
                above_mask = cleaned[col] > max_val
                for idx in cleaned[above_mask].index:
                    old_val = cleaned.loc[idx, col]
                    cleaned.at[idx, col] = max_val
                    modifications.append({
                        "rule_id": rule_id,
                        "rule_type": rtype,
                        "action": "clamp_range",
                        "column": col,
                        "row_index": int(idx),
                        "old_value": old_val,
                        "new_value": max_val,
                    })

        # Handle regex constraints with enhanced repair strategies.
        elif rtype == "regex":
            pattern = rule.get("pattern")
            if not pattern:
                continue
            try:
                compiled = re.compile(pattern)
            except Exception:
                continue
            non_match_mask = ~cleaned[col].astype(str).apply(lambda x: bool(compiled.match(x)))
            for idx in cleaned[non_match_mask].index:
                old_val = cleaned.loc[idx, col]
                # Try to fix common issues: remove invalid characters, trim whitespace
                fixed_val = str(old_val).strip()
                # Remove characters that don't match the pattern's character class
                if '^[' in pattern and ']+$' in pattern:
                    # Extract allowed characters from pattern like ^[A-Za-z0-9-]+$
                    char_class_match = re.search(r'\^\[([^\]]+)\]\+\$', pattern)
                    if char_class_match:
                        allowed_chars = set(char_class_match.group(1).replace('\\-', '-'))
                        fixed_val = ''.join(c for c in fixed_val if c in allowed_chars or c.isalnum() or c == '-')
                
                # Try matching again
                if compiled.match(fixed_val):
                    cleaned.at[idx, col] = fixed_val
                    modifications.append({
                        "rule_id": rule_id,
                        "rule_type": rtype,
                        "action": "regex_fix_enhanced",
                        "column": col,
                        "row_index": int(idx),
                        "old_value": old_val,
                        "new_value": fixed_val,
                    })
                else:
                    # Find closest matching value from column
                    matching_values = cleaned[col][cleaned[col].astype(str).apply(lambda x: bool(compiled.match(x)))].tolist()
                    if matching_values:
                        # Use mode of matching values as replacement
                        replacement = Counter(matching_values).most_common(1)[0][0]
                        cleaned.at[idx, col] = replacement
                        modifications.append({
                            "rule_id": rule_id,
                            "rule_type": rtype,
                            "action": "regex_fix_fallback",
                            "column": col,
                            "row_index": int(idx),
                            "old_value": old_val,
                            "new_value": replacement,
                        })
                    else:
                        # Last resort: set to None
                        cleaned.at[idx, col] = None
                        modifications.append({
                            "rule_id": rule_id,
                            "rule_type": rtype,
                            "action": "regex_fix_null",
                            "column": col,
                            "row_index": int(idx),
                            "old_value": old_val,
                            "new_value": None,
                        })

        # Handle functional dependency rules by unifying dependent values.
        elif rtype == "fd":
            determinant = rule.get("determinant")
            dependent = rule.get("dependent")
            if determinant not in cleaned.columns or dependent not in cleaned.columns:
                continue
            # For each determinant value, find the first observed dependent value.
            mapping = cleaned.dropna(subset=[determinant, dependent]).groupby(determinant)[dependent].first().to_dict()
            for idx, row in cleaned.iterrows():
                det_val = row[determinant]
                dep_val = row[dependent]
                # Skip rows with missing determinant or dependent.
                if pd.isna(det_val) or pd.isna(dep_val):
                    continue
                expected = mapping.get(det_val)
                if expected is not None and dep_val != expected:
                    old_val = dep_val
                    cleaned.at[idx, dependent] = expected
                    modifications.append({
                        "rule_id": rule_id,
                        "rule_type": rtype,
                        "action": "fd_fix",
                        "column": dependent,
                        "row_index": int(idx),
                        "old_value": old_val,
                        "new_value": expected,
                    })

        # Handle approximate functional dependency rules by unifying the
        # dependent values according to the most frequent value for each
        # determinant. Values that deviate from the mode are replaced.
        elif rtype == "approx_fd":
            determinant = rule.get("determinant")
            dependent = rule.get("dependent")
            if determinant not in cleaned.columns or dependent not in cleaned.columns:
                continue
            # Build mapping: for each determinant value, find the most
            # frequent dependent value (mode). If there is a tie, choose
            # the first encountered.
            group_mode = cleaned.groupby(determinant)[dependent].agg(lambda x: x.mode().iloc[0] if not x.mode().empty else x.iloc[0]).to_dict()
            for idx, row in cleaned.iterrows():
                det_val = row.get(determinant)
                dep_val = row.get(dependent)
                if pd.isna(det_val) or pd.isna(dep_val):
                    continue
                expected = group_mode.get(det_val)
                if expected is not None and dep_val != expected:
                    old_val = dep_val
                    cleaned.at[idx, dependent] = expected
                    modifications.append({
                        "rule_id": rule_id,
                        "rule_type": rtype,
                        "action": "approx_fd_fix",
                        "column": dependent,
                        "row_index": int(idx),
                        "old_value": old_val,
                        "new_value": expected,
                    })

        # Handle conditional functional dependency rules. For each value of
        # the condition column, apply a strict FD between determinant and
        # dependent within that subset.
        elif rtype == "conditional_fd":
            determinant = rule.get("determinant")
            dependent = rule.get("dependent")
            condition = rule.get("condition")
            if not all(c in cleaned.columns for c in (determinant, dependent, condition)):
                continue
            # Group by condition column and compute mode mapping within each group.
            for cond_val, subset in cleaned.groupby(condition):
                mapping = subset.groupby(determinant)[dependent].agg(lambda x: x.mode().iloc[0] if not x.mode().empty else x.iloc[0]).to_dict()
                # For each row in this group, replace dependent with expected mode.
                indices = subset.index
                for idx in indices:
                    det_val = cleaned.at[idx, determinant]
                    dep_val = cleaned.at[idx, dependent]
                    if pd.isna(det_val) or pd.isna(dep_val):
                        continue
                    expected = mapping.get(det_val)
                    if expected is not None and dep_val != expected:
                        old_val = dep_val
                        cleaned.at[idx, dependent] = expected
                        modifications.append({
                            "rule_id": rule_id,
                            "rule_type": rtype,
                            "action": "conditional_fd_fix",
                            "column": dependent,
                            "row_index": int(idx),
                            "old_value": old_val,
                            "new_value": expected,
                        })

        # Handle missing pattern rules by blanking the secondary column when
        # the primary column is missing. This ensures that the co‑missingness
        # pattern is enforced.
        elif rtype == "missing_pattern":
            a = rule.get("when_missing")
            b = rule.get("also_missing")
            if a in cleaned.columns and b in cleaned.columns:
                mask = cleaned[a].isna() & cleaned[b].notna()
                for idx in cleaned[mask].index:
                    old_val = cleaned.loc[idx, b]
                    cleaned.at[idx, b] = None
                    modifications.append({
                        "rule_id": rule_id,
                        "rule_type": rtype,
                        "action": "missing_pattern_fix",
                        "column": b,
                        "row_index": int(idx),
                        "old_value": old_val,
                        "new_value": None,
                    })

        # Handle domain‑specific regex constraints similarly to generic regex.
        elif rtype == "regex_domain":
            pattern = rule.get("pattern")
            if not pattern:
                continue
            try:
                compiled = re.compile(pattern)
            except Exception:
                continue
            non_match_mask = ~cleaned[col].astype(str).apply(lambda x: bool(compiled.match(x)))
            for idx in cleaned[non_match_mask].index:
                old_val = cleaned.loc[idx, col]
                cleaned.at[idx, col] = None
                modifications.append({
                    "rule_id": rule_id,
                    "rule_type": rtype,
                    "action": "regex_domain_fix",
                    "column": col,
                    "row_index": int(idx),
                    "old_value": old_val,
                    "new_value": None,
                })

        # Handle categorical constraints by replacing unknown categories with the most frequent value.
        elif rtype == "categorical":
            allowed = rule.get("values", [])
            if not allowed:
                continue
            # Determine the fallback value (most frequent in allowed list by occurrence in the data).
            counts = cleaned[col].value_counts()
            fallback = None
            for val in allowed:
                if val in counts:
                    fallback = val
                    break
            # If no allowed value appears in the data, use the first allowed value as fallback.
            if fallback is None and allowed:
                fallback = allowed[0]
            # Replace disallowed values.
            mask = ~cleaned[col].isin(allowed)
            for idx in cleaned[mask].index:
                old_val = cleaned.loc[idx, col]
                cleaned.at[idx, col] = fallback
                modifications.append({
                    "rule_id": rule_id,
                    "rule_type": rtype,
                    "action": "categorical_fix",
                    "column": col,
                    "row_index": int(idx),
                    "old_value": old_val,
                    "new_value": fallback,
                })

        # Handle outlier rules by clamping values outside mean ± z_thresh*std.
        elif rtype == "outlier":
            mean = rule.get("mean")
            std = rule.get("std")
            z_thresh = rule.get("z_thresh", 3.0)
            if mean is None or std is None or std == 0:
                continue
            upper = mean + z_thresh * std
            lower = mean - z_thresh * std
            # Clamp values below lower threshold.
            below_mask = cleaned[col] < lower
            for idx in cleaned[below_mask].index:
                old_val = cleaned.loc[idx, col]
                cleaned.at[idx, col] = lower
                modifications.append({
                    "rule_id": rule_id,
                    "rule_type": rtype,
                    "action": "outlier_clamp",
                    "column": col,
                    "row_index": int(idx),
                    "old_value": old_val,
                    "new_value": lower,
                })
            # Clamp values above upper threshold.
            above_mask = cleaned[col] > upper
            for idx in cleaned[above_mask].index:
                old_val = cleaned.loc[idx, col]
                cleaned.at[idx, col] = upper
                modifications.append({
                    "rule_id": rule_id,
                    "rule_type": rtype,
                    "action": "outlier_clamp",
                    "column": col,
                    "row_index": int(idx),
                    "old_value": old_val,
                    "new_value": upper,
                })

        # Handle standardization rules by converting case.
        elif rtype == "standardize":
            target_format = rule.get("format")
            if not target_format or df[col].dtype != object:
                continue
            for idx, val in cleaned[col].astype(str).items():
                if target_format == "uppercase" and val != val.upper():
                    cleaned.at[idx, col] = val.upper()
                    modifications.append({
                        "rule_id": rule_id,
                        "rule_type": rtype,
                        "action": "standardize",
                        "column": col,
                        "row_index": int(idx),
                        "old_value": val,
                        "new_value": val.upper(),
                    })
                elif target_format == "lowercase" and val != val.lower():
                    cleaned.at[idx, col] = val.lower()
                    modifications.append({
                        "rule_id": rule_id,
                        "rule_type": rtype,
                        "action": "standardize",
                        "column": col,
                        "row_index": int(idx),
                        "old_value": val,
                        "new_value": val.lower(),
                    })

        # Handle inclusion dependency rules with enhanced repair strategies.
        elif rtype == "inclusion":
            subset = rule.get("subset")
            superset = rule.get("superset")
            if subset is None or superset is None:
                continue
            if subset not in cleaned.columns or superset not in cleaned.columns:
                continue
            superset_values = set(cleaned[superset].dropna().tolist())
            mask = ~cleaned[subset].isin(superset_values)
            for idx in cleaned[mask].index:
                old_val = cleaned.loc[idx, subset]
                # Try fuzzy matching: find closest value in superset
                if pd.notna(old_val):
                    old_str = str(old_val).lower().strip()
                    # Try exact case-insensitive match
                    matches = [v for v in superset_values if str(v).lower().strip() == old_str]
                    if matches:
                        replacement = matches[0]
                        cleaned.at[idx, subset] = replacement
                        modifications.append({
                            "rule_id": rule_id,
                            "rule_type": rtype,
                            "action": "inclusion_fix_fuzzy",
                            "column": subset,
                            "row_index": int(idx),
                            "old_value": old_val,
                            "new_value": replacement,
                        })
                        continue
                    # Try partial match (contains)
                    matches = [v for v in superset_values if old_str in str(v).lower() or str(v).lower() in old_str]
                    if matches:
                        replacement = matches[0]
                        cleaned.at[idx, subset] = replacement
                        modifications.append({
                            "rule_id": rule_id,
                            "rule_type": rtype,
                            "action": "inclusion_fix_partial",
                            "column": subset,
                            "row_index": int(idx),
                            "old_value": old_val,
                            "new_value": replacement,
                        })
                        continue
                
                # No match found: use mode of valid subset values
                valid_subset_values = cleaned[subset][cleaned[subset].isin(superset_values)].tolist()
                if valid_subset_values:
                    replacement = Counter(valid_subset_values).most_common(1)[0][0]
                    cleaned.at[idx, subset] = replacement
                    modifications.append({
                        "rule_id": rule_id,
                        "rule_type": rtype,
                        "action": "inclusion_fix_fallback",
                        "column": subset,
                        "row_index": int(idx),
                        "old_value": old_val,
                        "new_value": replacement,
                    })
                else:
                    # Last resort: set to None
                    cleaned.at[idx, subset] = None
                    modifications.append({
                        "rule_id": rule_id,
                        "rule_type": rtype,
                        "action": "inclusion_fix_null",
                        "column": subset,
                        "row_index": int(idx),
                        "old_value": old_val,
                        "new_value": None,
                    })

        # Additional rule types would be handled here.

    return cleaned.reset_index(drop=True), modifications