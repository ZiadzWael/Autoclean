"""Feedback storage and learning utilities.

User feedback on rule sets and data repairs is stored and analyzed to improve
future rule extraction.
"""

from pathlib import Path
from datetime import datetime
from typing import List, Dict, Any
import json
import re

from ..config import DATA_DIR
from .rag.retriever import Retriever

# Feedback file path.
_FEEDBACK_FILE = DATA_DIR / "feedback.log"


def save_feedback(rule_set_id: str, feedback: str) -> None:
    """Append a feedback entry to the feedback log and index it in RAG.

    Parameters
    ----------
    rule_set_id : str
        Identifier of the rule set the feedback refers to.
    feedback : str
        User feedback text.
    """
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    timestamp = datetime.utcnow().isoformat()
    with _FEEDBACK_FILE.open("a", encoding="utf-8") as f:
        f.write(f"{timestamp}\t{rule_set_id}\t{feedback}\n")
    
    # Index feedback in RAG for learning
    retriever = Retriever()
    retriever.add_domain_knowledge(
        f"Feedback for rule_set {rule_set_id}: {feedback}",
        domain="feedback"
    )


def load_feedback(rule_set_id: str | None = None) -> List[Dict[str, Any]]:
    """Load feedback entries, optionally filtered by rule_set_id.

    Parameters
    ----------
    rule_set_id : str, optional
        Filter feedback by rule set ID.

    Returns
    -------
    list[dict[str, Any]]
        List of feedback entries.
    """
    if not _FEEDBACK_FILE.exists():
        return []
    
    feedback_entries = []
    with _FEEDBACK_FILE.open("r", encoding="utf-8") as f:
        for line in f:
            parts = line.strip().split("\t", 2)
            if len(parts) >= 3:
                timestamp, rs_id, feedback = parts
                if rule_set_id is None or rs_id == rule_set_id:
                    feedback_entries.append({
                        "timestamp": timestamp,
                        "rule_set_id": rs_id,
                        "feedback": feedback
                    })
    
    return feedback_entries


def analyze_feedback_for_improvements() -> Dict[str, Any]:
    """Analyze feedback to extract patterns and improvements.

    Returns
    -------
    dict[str, Any]
        Analysis results with common issues and suggestions.
    """
    all_feedback = load_feedback()
    
    # Simple keyword analysis
    issues = {
        "too_many_rules": 0,
        "too_few_rules": 0,
        "low_quality": 0,
        "conflicts": 0,
        "missing_rules": 0
    }
    
    for entry in all_feedback:
        feedback_lower = entry["feedback"].lower()
        if "too many" in feedback_lower or "excessive" in feedback_lower:
            issues["too_many_rules"] += 1
        if "too few" in feedback_lower or "missing" in feedback_lower:
            issues["too_few_rules"] += 1
        if "low quality" in feedback_lower or "bad" in feedback_lower:
            issues["low_quality"] += 1
        if "conflict" in feedback_lower or "contradict" in feedback_lower:
            issues["conflicts"] += 1
        if "need" in feedback_lower or "should have" in feedback_lower:
            issues["missing_rules"] += 1
    
    return {
        "total_feedback": len(all_feedback),
        "common_issues": issues,
        "suggestions": _generate_suggestions(issues)
    }


def _generate_suggestions(issues: Dict[str, int]) -> List[str]:
    """Generate suggestions based on common issues."""
    suggestions = []
    if issues["too_many_rules"] > issues["too_few_rules"]:
        suggestions.append("Consider increasing confidence threshold to filter more rules")
    if issues["conflicts"] > 0:
        suggestions.append("Improve conflict detection and resolution")
    if issues["low_quality"] > 0:
        suggestions.append("Enhance rule quality scoring and curation")
    return suggestions


def get_feedback_context(query: str, top_k: int = 3) -> List[str]:
    """Retrieve relevant feedback using RAG.

    Parameters
    ----------
    query : str
        Search query.
    top_k : int, default 3
        Number of results to return.

    Returns
    -------
    list[str]
        Relevant feedback entries.
    """
    retriever = Retriever()
    results = retriever.retrieve(query, top_k=top_k)
    return [r["content"] for r in results if r.get("metadata", {}).get("type") == "domain_knowledge"]