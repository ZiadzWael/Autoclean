"""Validation logic for applying data quality rules to datasets.

The validator inspects a DataFrame against a set of rule definitions and
reports any violations. Each violation record includes the rule, the
column name, and the number of offending rows.
"""

from __future__ import annotations
from typing import List, Dict, Any
import pandas as pd
import re


def validate_dataframe(df: pd.DataFrame, rules: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """Validate a DataFrame against a list of rule dictionaries.

    Parameters
    ----------
    df : pd.DataFrame
        The DataFrame to validate.
    rules : list[dict[str, Any]]
        The rules to apply.

    Returns
    -------
    list[dict[str, Any]]
        A list of violation records.
    """
    violations: list[dict[str, Any]] = []

    for rule in rules:
        col = rule.get("column")
        rtype = rule.get("type")
        if col not in df.columns:
            # Column not present; skip.
            continue

        if rtype == "not_null":
            missing_mask = df[col].isna()
            count = int(missing_mask.sum())
            if count > 0:
                violations.append(
                    {"column": col, "type": rtype, "count": count}
                )

        elif rtype == "unique":
            dup_mask = df[col].duplicated()
            count = int(dup_mask.sum())
            if count > 0:
                violations.append(
                    {"column": col, "type": rtype, "count": count}
                )

        elif rtype == "range":
            min_val = rule.get("min")
            max_val = rule.get("max")
            out_of_range_mask = pd.Series(False, index=df.index)
            if min_val is not None:
                out_of_range_mask |= df[col] < min_val
            if max_val is not None:
                out_of_range_mask |= df[col] > max_val
            count = int(out_of_range_mask.sum())
            if count > 0:
                violations.append(
                    {"column": col, "type": rtype, "count": count}
                )

        elif rtype == "regex":
            # Count values that do not match the regex pattern.
            pattern = rule.get("pattern")
            if pattern:
                try:
                    compiled = re.compile(pattern)
                except Exception:
                    continue
                non_match_mask = ~df[col].astype(str).apply(lambda x: bool(compiled.match(x)))
                count = int(non_match_mask.sum())
                if count > 0:
                    violations.append({"column": col, "type": rtype, "count": count})

        elif rtype == "regex_domain":
            # Same as regex but using the provided domain pattern.
            pattern = rule.get("pattern")
            if pattern:
                try:
                    compiled = re.compile(pattern)
                except Exception:
                    continue
                non_match_mask = ~df[col].astype(str).apply(lambda x: bool(compiled.match(x)))
                count = int(non_match_mask.sum())
                if count > 0:
                    violations.append({"column": col, "type": rtype, "count": count})

        elif rtype == "fd":
            # Functional dependency validation: count rows that violate the FD.
            determinant = rule.get("determinant")
            dependent = rule.get("dependent")
            if determinant not in df.columns or dependent not in df.columns:
                continue
            # Build mapping for dependent values per determinant.
            mapping = df.groupby(determinant)[dependent].first().to_dict()
            # Count mismatches.
            mismatches = df.apply(lambda row: row[dependent] != mapping.get(row[determinant]) if pd.notna(row[determinant]) and pd.notna(row[dependent]) else False, axis=1)
            count = int(mismatches.sum())
            if count > 0:
                violations.append({"column": dependent, "type": rtype, "count": count})

        elif rtype == "approx_fd":
            determinant = rule.get("determinant")
            dependent = rule.get("dependent")
            if determinant not in df.columns or dependent not in df.columns:
                continue
            mapping = df.groupby(determinant)[dependent].agg(lambda x: x.mode().iloc[0] if not x.mode().empty else x.iloc[0]).to_dict()
            mismatches = df.apply(lambda row: row[dependent] != mapping.get(row[determinant]) if pd.notna(row[determinant]) and pd.notna(row[dependent]) else False, axis=1)
            count = int(mismatches.sum())
            if count > 0:
                violations.append({"column": dependent, "type": rtype, "count": count})

        elif rtype == "conditional_fd":
            determinant = rule.get("determinant")
            dependent = rule.get("dependent")
            condition = rule.get("condition")
            if not all(c in df.columns for c in (determinant, dependent, condition)):
                continue
            count = 0
            for _, subset in df.groupby(condition):
                mapping = subset.groupby(determinant)[dependent].agg(lambda x: x.mode().iloc[0] if not x.mode().empty else x.iloc[0]).to_dict()
                mismatches = subset.apply(lambda row: row[dependent] != mapping.get(row[determinant]) if pd.notna(row[determinant]) and pd.notna(row[dependent]) else False, axis=1)
                count += int(mismatches.sum())
            if count > 0:
                violations.append({"column": dependent, "type": rtype, "count": count})

        elif rtype == "categorical":
            allowed = rule.get("values", [])
            if allowed:
                mask = ~df[col].isin(allowed)
                count = int(mask.sum())
                if count > 0:
                    violations.append({"column": col, "type": rtype, "count": count})

        elif rtype == "outlier":
            mean = rule.get("mean")
            std = rule.get("std")
            z_thresh = rule.get("z_thresh", 3.0)
            if mean is not None and std is not None and std > 0:
                upper = mean + z_thresh * std
                lower = mean - z_thresh * std
                outlier_mask = (df[col] < lower) | (df[col] > upper)
                count = int(outlier_mask.sum())
                if count > 0:
                    violations.append({"column": col, "type": rtype, "count": count})

        elif rtype == "standardize":
            target_format = rule.get("format")
            if target_format and df[col].dtype == object:
                if target_format == "uppercase":
                    mask = df[col].astype(str).apply(lambda x: x != x.upper())
                elif target_format == "lowercase":
                    mask = df[col].astype(str).apply(lambda x: x != x.lower())
                else:
                    mask = pd.Series(False, index=df.index)
                count = int(mask.sum())
                if count > 0:
                    violations.append({"column": col, "type": rtype, "count": count})

        elif rtype == "inclusion":
            subset = rule.get("subset")
            superset = rule.get("superset")
            if subset in df.columns and superset in df.columns:
                superset_values = set(df[superset].dropna().tolist())
                mask = ~df[subset].isin(superset_values)
                count = int(mask.sum())
                if count > 0:
                    violations.append({"column": subset, "type": rtype, "count": count})

        elif rtype == "missing_pattern":
            a = rule.get("when_missing")
            b = rule.get("also_missing")
            if a in df.columns and b in df.columns:
                mask = df[a].isna() & df[b].notna()
                count = int(mask.sum())
                if count > 0:
                    violations.append({"column": b, "type": rtype, "count": count})

    return violations