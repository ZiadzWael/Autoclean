"""Dataset storage utilities.

Functions in this module handle persistence of datasets on disk. Uploaded
datasets are stored in the `data/storage` directory with a UUID-based
prefix to avoid collisions. The storage layer is simple and does not
currently support database-backed file management.
"""

import uuid
from pathlib import Path
import pandas as pd

from ..config import STORAGE_DIR


def save_dataset(df: pd.DataFrame, filename: str) -> str:
    """Persist a DataFrame to CSV in the storage directory.

    A UUID is prepended to the original filename to create a unique path.

    Parameters
    ----------
    df : pd.DataFrame
        The DataFrame to save.
    filename : str
        The original filename supplied by the client.

    Returns
    -------
    str
        The generated dataset identifier.
    """
    print(f"[STORAGE] Creating directory: {STORAGE_DIR}")
    STORAGE_DIR.mkdir(parents=True, exist_ok=True)
    
    dataset_id = uuid.uuid4().hex
    # Sanitize filename - remove problematic characters
    safe_name = filename.replace("/", "_").replace("\\", "_").replace(":", "_")
    path = STORAGE_DIR / f"{dataset_id}_{safe_name}"
    
    print(f"[STORAGE] Saving to: {path}")
    df.to_csv(path, index=False)
    print(f"[STORAGE] Saved successfully")
    
    return dataset_id