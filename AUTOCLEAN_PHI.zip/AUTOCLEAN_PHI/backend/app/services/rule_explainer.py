"""Natural language explanations for data quality rules.

This module converts machine-readable rule definitions into human-friendly
descriptions, optionally using LLM for enhanced explanations.
"""

from typing import List, Dict, Any, Optional
import json

from .llm.client import LLMClient
from .llm.prompts import RULE_EXPLANATION_PROMPT
from .profiler import profile_dataframe
import pandas as pd


def explain_rules(rules: List[Dict[str, Any]], df: Optional[pd.DataFrame] = None, use_llm: bool = False) -> List[str]:
    """Generate human-readable explanations for each rule.

    Parameters
    ----------
    rules : list[dict[str, Any]]
        The rule definitions.
    df : pd.DataFrame, optional
        Optional DataFrame for context (used with LLM).
    use_llm : bool, default False
        Whether to use LLM for enhanced explanations.

    Returns
    -------
    list[str]
        Explanatory strings for each rule.
    """
    explanations: list[str] = []
    llm = LLMClient(backend="phi3") if use_llm else None
    profile = profile_dataframe(df) if df is not None else None

    for rule in rules:
        col = rule.get("column")
        rtype = rule.get("type")
        
        # Basic explanations
        if rtype == "not_null":
            explanation = f"Column '{col}' must not contain missing values."
        elif rtype == "unique":
            explanation = f"Column '{col}' must contain unique values (no duplicates)."
        elif rtype == "range":
            min_val = rule.get("min")
            max_val = rule.get("max")
            explanation = f"Values in column '{col}' must fall between {min_val} and {max_val}."
        elif rtype == "categorical":
            values = rule.get("values", [])
            values_str = ", ".join(str(v) for v in values[:5])
            if len(values) > 5:
                values_str += f", ... ({len(values)} total)"
            explanation = f"Column '{col}' must contain only these values: {values_str}."
        elif rtype == "regex":
            pattern = rule.get("pattern", "")
            explanation = f"Column '{col}' must match the pattern: {pattern}."
        elif rtype == "fd":
            determinant = rule.get("determinant")
            dependent = rule.get("dependent")
            explanation = f"Functional dependency: {determinant} → {dependent} (each {determinant} value determines {dependent})."
        elif rtype == "outlier":
            mean = rule.get("mean")
            std = rule.get("std")
            z_thresh = rule.get("z_thresh", 3.0)
            explanation = f"Column '{col}' values outside {z_thresh} standard deviations from mean ({mean:.2f} ± {z_thresh * std:.2f}) are outliers."
        elif rtype == "standardize":
            format_type = rule.get("format", "")
            explanation = f"Column '{col}' should be standardized to {format_type}."
        elif rtype == "inclusion":
            subset = rule.get("subset")
            superset = rule.get("superset")
            explanation = f"Inclusion dependency: values in '{subset}' must be a subset of values in '{superset}'."
        else:
            explanation = f"Rule on column '{col}' of type '{rtype}'."
        
        # Enhance with LLM if requested
        if use_llm and llm and profile and col:
            try:
                col_profile = profile.get("columns", {}).get(col, {})
                prompt = RULE_EXPLANATION_PROMPT.format(
                    rule=json.dumps(rule, indent=2),
                    column_profile=json.dumps(col_profile, indent=2)
                )
                enhanced = llm.complete(prompt).strip()
                if enhanced and len(enhanced) > 20:  # Only use if meaningful
                    explanation = enhanced
            except Exception:
                pass  # Fall back to basic explanation
        
        explanations.append(explanation)
    
    return explanations