"""Placeholder extractor planner for rule generation.

In a more advanced implementation this module would plan interactions with
the LLM to extract rules incrementally. In PH1 it is left unimplemented.
"""


class ExtractorPlanner:
    """Stub class for an extractor planner."""

    def plan(self, profile: dict) -> str:
        """Return a prompt for rule extraction based on a profile."""
        raise NotImplementedError("Extractor planner not implemented")