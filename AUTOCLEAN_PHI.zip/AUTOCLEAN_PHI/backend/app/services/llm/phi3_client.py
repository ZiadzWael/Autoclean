"""Local Phi-3 mini client for inference.

This client loads the Phi-3 mini model from a local path and exposes a
simple generate method. The model is loaded onto the CUDA device if
available.
"""

from __future__ import annotations

import torch
from transformers import AutoModelForCausalLM, AutoTokenizer

from ...config import PHI3_MODEL_PATH, DEVICE, MAX_NEW_TOKENS, TEMPERATURE


class Phi3Client:
    """Wrapper around the Phi-3 mini language model."""

    def __init__(self) -> None:
        # Load tokenizer and model. trust_remote_code allows custom
        # configuration for Phi-3 models.
        self.tokenizer = AutoTokenizer.from_pretrained(
            PHI3_MODEL_PATH,
            trust_remote_code=True
        )
        # Phi-3 requires specific settings to avoid DynamicCache issues
        self.model = AutoModelForCausalLM.from_pretrained(
            PHI3_MODEL_PATH,
            device_map="auto",
            torch_dtype=torch.float16,
            trust_remote_code=True,
            attn_implementation='eager',
            use_cache=False  # Disable cache to avoid compatibility issues
        )
        self.device = DEVICE if torch.cuda.is_available() else "cpu"
        print(f"[PHI3] Model loaded on device: {self.device}")

    def generate(self, prompt: str) -> str:
        """Generate a completion for the given prompt.

        Parameters
        ----------
        prompt : str
            The input text prompt.

        Returns
        -------
        str
            The generated completion text.
        """
        try:
            inputs = self.tokenizer(prompt, return_tensors="pt").to(self.device)
            with torch.no_grad():
                output = self.model.generate(
                    **inputs,
                    max_new_tokens=MAX_NEW_TOKENS,
                    do_sample=False,  # Use greedy decoding
                    use_cache=False,  # Disable cache
                    pad_token_id=self.tokenizer.eos_token_id
                )
            result = self.tokenizer.decode(output[0], skip_special_tokens=True)
            print(f"[PHI3] Generated {len(result)} chars")
            return result
        except Exception as e:
            print(f"[PHI3] Generation error: {e}")
            raise