"""Phi-3 specific extractor planner that selects which extractors to use."""

from __future__ import annotations

import json
import re
import traceback
from typing import List

from .client import LLMClient
from .prompts import EXTRACTOR_SELECTION_PROMPT


class Phi3ExtractorPlanner:
    """Plans which rule extractors to use based on data profile."""

    def __init__(self) -> None:
        try:
            self.llm = LLMClient(backend="phi3")
        except Exception as e:
            print(f"[PLANNER] LLM init failed: {e}")
            self.llm = None

    def select_extractors(self, profile: dict) -> List[str]:
        """Select which extractors to use based on the data profile.

        Parameters
        ----------
        profile : dict
            The dataset profile dictionary.

        Returns
        -------
        list[str]
            List of extractor function names to use.
        """
        default_extractors = [
            "extract_rules_from_profile",
            "find_categorical_rules",
            "find_regex_rules",
            "find_fd_rules",
            "find_outlier_rules",
            "find_standardize_rules",
            "find_inclusion_rules"
        ]
        
        # If LLM not available, use defaults
        if self.llm is None:
            print(f"[PLANNER] LLM unavailable, using default extractors")
            return default_extractors
        
        try:
            prompt = EXTRACTOR_SELECTION_PROMPT.format(profile=json.dumps(profile, indent=2))
            response = self.llm.complete(prompt)
            print(f"[PLANNER] LLM response (first 200 chars): {response[:200]}")
            print(f"[PLANNER] Response length: {len(response)}")
            
            # Try to extract JSON from response
            try:
                # Find the JSON object in the response
                start = response.find('{')
                if start < 0:
                    print(f"[PLANNER] No JSON object found in response, using defaults")
                    return default_extractors
                
                # Find the matching closing brace
                end = response.rfind('}')
                if end < start:
                    print(f"[PLANNER] No matching closing brace found, using defaults")
                    return default_extractors
                
                # Extract and parse JSON
                json_str = response[start:end+1].strip()
                print(f"[PLANNER] Extracted JSON string (first 100 chars): {json_str[:100]}")
                
                result = json.loads(json_str)
                print(f"[PLANNER] Successfully parsed JSON: {result}")
                
                extractors = result.get("recommended_extractors", [])
                # Validate extractor names
                valid_extractors = [
                    "extract_rules_from_profile",
                    "find_categorical_rules",
                    "find_regex_rules",
                    "find_fd_rules",
                    "find_outlier_rules",
                    "find_standardize_rules",
                    "find_inclusion_rules"
                ]
                selected = [e for e in extractors if e in valid_extractors]
                if selected:
                    print(f"[PLANNER] Selected {len(selected)} extractors: {selected}")
                    return selected
                else:
                    print(f"[PLANNER] No valid extractors found in response, using defaults")
                    return default_extractors
                    
            except (json.JSONDecodeError, KeyError, ValueError, TypeError) as e:
                print(f"[PLANNER] JSON parse failed: {e}")
                print(f"[PLANNER] Attempting fallback extraction...")
                # Try alternative JSON extraction if first attempt fails
                try:
                    import re
                    # Try to extract JSON using regex as last resort
                    json_match = re.search(r'\{[^{}]*\}', response, re.DOTALL)
                    if json_match:
                        result = json.loads(json_match.group(0))
                        extractors = result.get("recommended_extractors", [])
                        valid_extractors = [
                            "extract_rules_from_profile",
                            "find_categorical_rules",
                            "find_regex_rules",
                            "find_fd_rules",
                            "find_outlier_rules",
                            "find_standardize_rules",
                            "find_inclusion_rules"
                        ]
                        selected = [e for e in extractors if e in valid_extractors]
                        if selected:
                            print(f"[PLANNER] Regex fallback successful: {selected}")
                            return selected
                except Exception as fallback_e:
                    print(f"[PLANNER] Regex fallback failed: {fallback_e}")
                
                print(f"[PLANNER] Using default extractors as fallback")
                return default_extractors
                
        except Exception as e:
            print(f"[PLANNER] Selection failed: {e}")
            traceback.print_exc()
        
        # Fallback: use all extractors if LLM fails
        print(f"[PLANNER] Using default extractors as fallback")
        return default_extractors