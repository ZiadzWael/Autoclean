"""Generic LLM client abstraction.

This module defines a simple interface for language model clients. It
delegates to a specific implementation such as Phi-3 or Dify.
"""

from __future__ import annotations

from typing import Protocol
import traceback

from .phi3_client import Phi3Client


class LLMClientProtocol(Protocol):
    """Protocol for LLM clients."""

    def generate(self, prompt: str) -> str: ...


class LLMClient:
    """A simple facade around a concrete LLM implementation."""

    def __init__(self, backend: str = "phi3") -> None:
        if backend == "phi3":
            try:
                print(f"[LLM] Initializing Phi3Client...")
                self.client: LLMClientProtocol = Phi3Client()
                print(f"[LLM] Phi3Client initialized successfully")
            except Exception as e:
                print(f"[LLM] Phi3Client init failed: {e}")
                traceback.print_exc()
                raise
        else:
            raise ValueError(f"Unsupported backend: {backend}")

    def complete(self, prompt: str) -> str:
        """Generate text from a prompt using the underlying LLM."""
        try:
            print(f"[LLM] Generating response...")
            response = self.client.generate(prompt)
            print(f"[LLM] Response generated ({len(response)} chars)")
            return response
        except Exception as e:
            print(f"[LLM] Generation failed: {e}")
            traceback.print_exc()
            raise