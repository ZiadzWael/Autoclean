"""Prompt templates for interacting with language models."""

# Template for extractor selection based on profile
EXTRACTOR_SELECTION_PROMPT = """You are a data quality expert. Analyze the dataset profile and recommend which rule extractors to use.

Available extractors:
1. extract_rules_from_profile - Basic rules (not_null, unique, range)
2. find_categorical_rules - For columns with limited unique values
3. find_regex_rules - For string columns with patterns
4. find_fd_rules - Functional dependencies between columns
5. find_outlier_rules - Statistical outliers in numeric columns
6. find_standardize_rules - Case standardization for strings
7. find_inclusion_rules - Subset relationships between columns

Dataset Profile:
{profile}

CRITICAL: Respond with ONLY a valid JSON object. No text before, after, or inside the JSON.
Do NOT include any explanation, preamble, or markdown formatting.

Example:
{{"recommended_extractors": ["extract_rules_from_profile", "find_categorical_rules"]}}

Now provide your JSON response:"""

# Template for rule curation and ranking
RULE_CURATION_PROMPT = """You are a data quality expert. Review and rank these extracted rules by quality and reliability.

Rules:
{rules}

For each rule, provide:
1. confidence_score: 0.0 to 1.0 (1.0 = very confident, 0.0 = uncertain)
2. reasoning: Brief explanation why this rule is good/bad
3. keep: true/false (should this rule be kept?)

Respond with a JSON array where each element has: {{"id": "R1", "confidence_score": 0.9, "reasoning": "...", "keep": true}}.
Be strict - only keep high-quality rules."""

# Template for rule explanation
RULE_EXPLANATION_PROMPT = """Explain this data quality rule in simple terms:

Rule: {rule}
Column Profile: {column_profile}

Provide a clear, concise explanation of what this rule means and why it was extracted. Maximum 2 sentences."""

# Template for rule extraction given a profile.
RULE_EXTRACTION_PROMPT = """
You are a data quality expert. Given the dataset profile below, extract:
- Missing value rules
- Range constraints
- Categorical constraints
- Uniqueness rules

Return the rules as a JSON list. Do not include any commentary.

DATA PROFILE:
{profile}
"""