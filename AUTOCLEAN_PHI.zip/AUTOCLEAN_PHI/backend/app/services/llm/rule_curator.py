"""Rule curator that refines and ranks rules using LLM."""

from __future__ import annotations

import json
import traceback
from typing import List, Dict, Any

from .client import LLMClient
from .prompts import RULE_CURATION_PROMPT


class RuleCurator:
    """Curates rule definitions via LLM to rank and filter rules."""

    def __init__(self) -> None:
        try:
            self.llm = LLMClient(backend="phi3")
        except Exception as e:
            print(f"[CURATOR] LLM init failed: {e}")
            self.llm = None

    def curate(self, rules: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """Curate rules by adding confidence scores and filtering low-quality ones.

        Parameters
        ----------
        rules : list[dict]
            List of extracted rules.

        Returns
        -------
        list[dict]
            Curated rules with confidence scores, filtered to keep only high-quality rules.
        """
        if not rules:
            return []

        # If LLM not available, add default scores and return
        if self.llm is None:
            print(f"[CURATOR] LLM unavailable, using default scoring")
            for rule in rules:
                rule.setdefault("confidence_score", 0.7)
                rule.setdefault("reasoning", "Default heuristic score")
            return rules

        try:
            prompt = RULE_CURATION_PROMPT.format(rules=json.dumps(rules, indent=2))
            response = self.llm.complete(prompt)
            print(f"[CURATOR] LLM response received")

            # Create a mapping of rule ID to rule for lookup
            rule_map = {rule.get("id", f"R{i+1}"): rule for i, rule in enumerate(rules)}

            try:
                # Try to extract JSON array from response
                start = response.find('[')
                end = response.rfind(']') + 1
                if start >= 0 and end > start:
                    curation_results = json.loads(response[start:end])
                    print(f"[CURATOR] Parsed {len(curation_results)} curation results")
                    
                    # Update rules with confidence scores and filter
                    curated_rules = []
                    for result in curation_results:
                        rule_id = result.get("id")
                        if rule_id in rule_map:
                            rule = rule_map[rule_id].copy()
                            rule["confidence_score"] = float(result.get("confidence_score", 0.5))
                            rule["reasoning"] = result.get("reasoning", "")
                            if result.get("keep", True):
                                curated_rules.append(rule)
                    
                    # Sort by confidence score (highest first)
                    curated_rules.sort(key=lambda x: x.get("confidence_score", 0.0), reverse=True)
                    print(f"[CURATOR] Curated to {len(curated_rules)} rules")
                    return curated_rules
            except (json.JSONDecodeError, KeyError, ValueError) as e:
                print(f"[CURATOR] JSON parse failed: {e}")
                traceback.print_exc()
                pass

        except Exception as e:
            print(f"[CURATOR] Curation failed: {e}")
            traceback.print_exc()

        # Fallback: add default confidence scores if LLM fails
        print(f"[CURATOR] Using fallback scoring")
        for rule in rules:
            rule.setdefault("confidence_score", 0.7)
            rule.setdefault("reasoning", "Extracted via heuristics")
        
        return rules