"""Entry point for the AutoClean PH1 FastAPI application.

This module constructs the FastAPI app and mounts the unified API router.
To run the application using uvicorn:

    uvicorn backend.app.main:app --reload --port 8001

"""

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from .api import api_router

app = FastAPI(
    title="AutoClean PH1",
    description="LLM-driven data cleaning assistant with continuous learning.",
    version="0.1.0",
)

# Add CORS middleware to allow frontend communication
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:3000", "http://localhost:8001", "*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Register all API routes.
app.include_router(api_router)